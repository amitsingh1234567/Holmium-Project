const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const User = require('../../models/Person');
const Jwt = require('jsonwebtoken');
const token = require('../../token-strategies/verify-token');
const Plant = require('../../models/Plant');
// const xl = require('excel4node');

const key = require('../../mongoDb-key/key').MongoURI


// const store = new mongoDb_Store_Session({
//     uri: key,
//     collection: 'mypeople',
//     ttl: 0 * 0 * 60 * 0
    
//   });

// // Session Config
// var session2 = (req, res, next) => {
//     session({
//         secret: 'myStront_Secret',
//         resave:true,
//         saveUninitialized:false,
//         store: store,
//       },
//       console.log('----------------'));
//       next();
// }


// var session2 = (req, res, next) => {
//         session({
//             secret: 'myStront_Secret',
//             resave:true,
//             saveUninitialized:false,
//             store: store,
            
//           },
//           console.log('----------------'));
//           next();
//     }


//  Login Route
router.post('/login',  (req, res) => {
    
    const { email, password } = req.body;
    User.findOne({ email: email })
        .then(person => {
            if (!person) {
                return res.json({ success: false, email_err: 'User not found with this email' });
            }
            bcrypt.compare(password, person.password)
                .then(isCorrect => {
                    if (!isCorrect) {
                        return res.json({ success: false, password_err: 'Password Incorrect' });
                    }
                    // res.json({msg: 'User able to Login'}) 3600
                    Jwt.sign({ id: person._id, email: person.email },
                        'myStrong_secret', { expiresIn: '1h' }, (err, token) => {
                            if (err) throw err;
                            // req.session = token
                            req.session.token = token;
                            req.session.user_id = person._id;
                            // person.session = req.session;
                            // person.save(person.session);
                            // console.log(person.session)
                            // person.session = 
                            // person.save('data').then(data => console.log(data))
                            // console.log(person)
                            // person.save(req.session).then(data => console.log(data))
                            // req.session.save()
                            return res.status(200).json({ success: true, token: token, expiresIn: 3600 });
                        })
                })
                .catch(err => console.log(err));
        })
        .catch(err => console.log(err));
});


router.get('/plantId', token.verifyToken,  (req, res) => {

    User.findById(req.data.id)
        .then(plntId => {
            return res.json({ plantId: plntId.plantId });
        })
        .catch(err => console.log(err));
});


router.get('/plantname/:id', token.verifyToken, (req, res) => {

    const id = req.params.id;
    Plant.findOne({ plantId: id })
        .then(plant => {
            return res.status(202).json({ plantName: plant.plantName, flag: plant.flag });
        })
        .catch(err => console.log(err));
});


router.get('/all-plantname', token.verifyToken, (req, res) => {

    var data = JSON.parse(req.query.plntId);
    var id1 = data[0].id;
    var id2 = data[1].id;
    var id3 = data[2].id;
     
    
    Plant.find({ $or: [{ plantId: id1 }, { plantId: id2 }, { plantId: id3 }] })
        .then(plantName => {
            return res.json({ plantname: plantName });
        })
        .catch(err => console.log(err));
});

// router.get('/excel-sheet', (req, res) => {
//     console.log('***********')
//     const wb = new xl.Workbook();
//     var ws = wb.addWorksheet('Sheet 1');
//     var style = wb.createStyle({
//         font: {
//           color: 'blue',
//           size: 13,
          
//         },
//         // numberFormat: '$#,##0.00; ($#,##0.00); -',
//       });
//       var style2 = wb.createStyle({
//         font: {
//           color: 'black',
//           size: 12,
//         },
//         // numberFormat: '$#,##0.00; ($#,##0.00); -',
//       });
//     const doc = [
//         {name:'Amit', email:'x@gmail.com', contact:'9576435668'},
//         {name:'Amit2', email:'x@gmail.com', contact:'9576235669'},
//         {name:'Amit3', email:'x@gmail.com', contact:'9516435660'},
//     ];

//     ws.cell(1,1).string('No').style(style);
//     ws.cell(1,2).string('Name').style(style);
//     ws.cell(1,3).string('Email').style(style);
//     ws.cell(1,4).string('Contact').style(style);

//     for(let i=0; doc.length > i; i++){
//         // ws.cell(i + 1, 1).string(doc[i].name).style(style2);
//         ws.cell(i+2, 1).number(i+1).style(style2);
//         ws.cell(i+2, 2).string(doc[i].name).style(style2);
//         ws.cell(i+2, 3).string(doc[i].email).style(style2);
//         ws.cell(i+2, 4).string(doc[i].contact).style(style2);
//     }

//     wb.write('Excel.xlsx',res);
// })


module.exports = router;
