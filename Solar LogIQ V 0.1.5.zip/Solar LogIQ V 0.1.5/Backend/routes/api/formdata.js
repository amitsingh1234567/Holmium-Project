const express = require('express');
const Formdata = require('../../models/formdata');
const router = express.Router();


router.post('/create', (req, res) => {
    // console.log(req.body)
    // return
    Formdata.findOne({ plantId: req.body.plantId })
        .then(plantId => {
            if (plantId) {
                return res.status(201).json({ success: false, message: 'Plant Id already exist' });
            }
            let emailIds = req.body.emailData;
            let mobileNumber = req.body.mobileNumberData;
            const newFormData = new Formdata({
                plantId: req.body.plantId,
                plantName: req.body.plantName,
                location: {
                    name: req.body.address,
                    type: 'point',
                    coordinates: [
                        req.body.latitude,
                        req.body.longitude
                    ]
                },
                commissioningDate: req.body.commissioningDate,
                licenseExpiryDate: req.body.licenseExpiryDate,
                owner: req.body.owner,
                unitPrice: req.body.unitPrice,
                plantCapacity: req.body.plantCapacity,
                PVModules: {
                    quantity: req.body.PVModulesQuantity,
                    make: req.body.PVModulesMake,
                    wattage: req.body.PVModulesWattage
                }
            });

            if (emailIds.length !== 0) {
                newFormData.emailId = { isActive: true };
                newFormData.emailId.details = [];
                emailIds.forEach(element => {
                    newFormData.emailId.details.push(element)
                });
            } else {
                newFormData.emailId = {
                    isActive: false
                }
            }

            if (mobileNumber.length !== 0) {
                newFormData.mobileNo = { isActive: true };
                newFormData.mobileNo.details = [];
                mobileNumber.forEach(element => {
                    newFormData.mobileNo.details.push(element);
                });
            } else {
                newFormData.mobileNo = { isActive: false };
            }

            if (req.body.stringInverterData == '') {
                newFormData.stringInverter = { isActive: false };
                newFormData.stringInverter.quantity = 0;
            } else {
                newFormData.stringInverter = { isActive: true };
                newFormData.stringInverter.quantity = req.body.stringInverterData.length;
                newFormData.stringInverter.details = [];
                req.body.stringInverterData.forEach((item, index) => {
                    newFormData.stringInverter.details.push({
                        id: index + 1,
                        name: item.name,
                        make: item.make,
                        capacity: item.capacity,
                        modelNo: item.modelNo,
                        serialNo: item.serialNo,
                        MPPT: item.MPPT,
                        string: item.string,
                        building: item.building,
                        buildingType: item.buildingType,
                        dataLoggerNo: item.dataLoggerNo,
                    });
                });
            }

            if (req.body.centralizedInverterData == '') {
                newFormData.centralizedInverter = { isActive: false };
                newFormData.centralizedInverter.quantity = req.body.centralizedInverterData.length;
            } else {
                newFormData.centralizedInverter = { isActive: true };
                newFormData.centralizedInverter.quantity = req.body.centralizedInverterData.length;
                newFormData.centralizedInverter.details = [];
                req.body.centralizedInverterData.forEach((element, index) => {
                    newFormData.centralizedInverter.details.push({
                        id: index + 1,
                        name: element.name,
                        make: element.make,
                        capacity: element.capacity,
                        modelNo: element.modelNo,
                        serialNo: element.serialNo,
                        MPPT: element.MPPT,
                        string: element.string,
                        building: element.building,
                        buildingType: element.buildingType,
                        dataLoggerNo: element.dataLoggerNo,
                    })
                })
            }

            if (req.body.weatherStationData == '') {
                newFormData.weatherStation = { isActive: false };
                newFormData.weatherStation.quantity = req.body.weatherStationData.length;
            } else {
                newFormData.weatherStation = { isActive: true };
                newFormData.weatherStation.quantity = req.body.weatherStationData.length;
                newFormData.weatherStation.details = [];
                req.body.weatherStationData.forEach((element, index) => {
                    newFormData.weatherStation.details.push({
                        id: index + 1,
                        name: element.name,
                        make: element.make,
                        sensors: element.sensors,
                        GHI: element.GHI,
                        GTI: element.GTI,
                        ambientTemperature: element.ambientTemperature,
                        moduleTemperature: element.moduleTemperature,
                        windSpeed: element.windSpeed,
                        windDirection: element.windDirection,
                        building: element.Building,
                        dataLoggerNo: element.dataLoggerNo,
                        priority: element.priority
                    })
                });
            }

            if (req.body.meterData == '') {
                newFormData.meter = { isActive: false };
                newFormData.meter.quantity = req.body.meterData.length;
            } else {
                newFormData.meter = { isActive: true };
                newFormData.meter.quantity = req.body.meterData.length;
                newFormData.meter.details = [];
                req.body.meterData.forEach((element, index) => {
                    newFormData.meter.details.push({
                        id: index + 1,
                        name: element.name,
                        make: element.make,
                        modelNo: element.modelNo,
                        serialNo: element.serialNo,
                        building: element.building,
                        buildingType: element.buildingType,
                        dataLoggerNo: element.dataLoggerNo,
                        htPannel: element.htPannel
                    });
                });
            }

            if (req.body.dieselGeneratorData == '') {
                newFormData.dieselGenerator = { isActive: false };
                newFormData.dieselGenerator.quantity = req.body.dieselGeneratorData.length;
            } else {
                newFormData.dieselGenerator = { isActive: true };
                newFormData.dieselGenerator.quantity = req.body.dieselGeneratorData.length;
                newFormData.dieselGenerator.details = [];
                req.body.dieselGeneratorData.forEach((element, index) => {
                    newFormData.dieselGenerator.details.push({
                        id: index + 1,
                        name: element.name,
                        make: element.make,
                        capacity: element.capacity,
                        modelNo: element.modelNo,
                        building: element.building,
                        dataLoggerNo: element.dataLoggerNo
                    })
                })
            }

            if (req.body.dataLoggerData == '') {
                newFormData.dataLogger = { isActive: false };
                newFormData.dataLogger.quantity = req.body.dataLoggerData.length;
            } else {
                newFormData.dataLogger = { isActive: true };
                newFormData.dataLogger.quantity = req.body.dataLoggerData.length;
                newFormData.dataLogger.details = [];
                req.body.dataLoggerData.forEach((element, index) => {
                    newFormData.dataLogger.details.push({
                        id: index + 1,
                        name: element.name,
                        make: element.make,
                        modelNo: element.modelNo,
                        serialNo: element.serialNo,
                        building: element.building,
                        deviceConnected: element.deviceConnected
                    });
                });
            }

            newFormData.save()
                .then(() => {
                    return res.status(200).json({ success: true, msg: 'Data added successfully..' });
                }).catch(err => console.log(err));
        }).catch(err => console.log(err))

});

router.post('/create/:action/:userID', (req, res) => {

    if (req.params.action == 'stringInverter') {
        var data = {
            stringInverter: {
                isActive: true,
                quantity: req.body.data.length,
                details: req.body.data
            }
        }
    };

    if (req.params.action == 'centralizedInverter') {
        var data = {
            centralizedInverter: {
                isActive: true,
                quantity: req.body.data.length,
                details: req.body.data
            }
        }
    };

    if (req.params.action == 'weatherStation') {
        var data = {
            weatherStation: {
                isActive: true,
                quantity: req.body.data.length,
                details: req.body.data
            }
        }
    };

    if (req.params.action == 'meter') {
        var data = {
            meter: {
                isActive: true,
                quantity: req.body.data.length,
                details: req.body.data
            }
        }
    }

    if (req.params.action == 'dieselGenerator') {
        var data = {
            dieselGenerator: {
                isActive: true,
                quantity: req.body.data.length,
                details: req.body.data
            }
        }
    };

    if (req.params.action == 'dataLogger') {
        var data = {
            dataLogger: {
                isActive: true,
                quantity: req.body.data.length,
                details: req.body.data
            }
        }
    };

    Formdata.findByIdAndUpdate({ _id: req.params.userID }, { $set: data }, { new: true })
        .then(doc => {
            return res.status(202).json({ success: true, msg: 'created' });
        })
        .catch(err => console.log(err));
});


router.patch('/update/:userID', async (req, res) => {

    const plantIdStatus = () => {
        if (req.body.emailData.length == 0) {
            var emailActive = false;
        } else {
            emailActive = true;
        }

        if (req.body.mobileNumberData.length == 0) {
            var numberActive = false;
        } else {
            numberActive = true
        }

        let user = {
            plantId: req.body.plantId,
            plantName: req.body.plantName,
            location: {
                name: req.body.address,
                type: 'point',
                coordinates: [
                    req.body.latitude,
                    req.body.longitude
                ]
            },
            commissioningDate: req.body.commissioningDate,
            licenseExpiryDate: req.body.licenseExpiryDate,
            owner: req.body.owner,
            unitPrice: req.body.unitPrice,
            plantCapacity: req.body.plantCapacity,
            PVModules: {
                quantity: req.body.PVModulesQuantity,
                make: req.body.PVModulesMake,
                wattage: req.body.PVModulesWattage
            },
            emailId: {
                isActive: emailActive,
                details: req.body.emailData
            },
            mobileNo: {
                isActive: numberActive,
                details: req.body.mobileNumberData
            },
        }
        Formdata.findByIdAndUpdate({ _id: req.params.userID }, { $set: user }, { new: true })
            .then(user => {
                return res.json({
                    success: true,
                    message: 'Updated successfully..'
                })
            })
            .catch(err => console.log(err));
    };

    if (req.body.newIdFlag) {
        Formdata.find().then(docs => {
            let plantIdExistOrNot = true;
            docs.forEach(item => {
                if (req.body.plantId == item.plantId) {
                    plantIdExistOrNot = false;
                    return res.status(200).json({
                        success: false,
                        message: 'Plant Id all ready exist'
                    });
                }
            });
            if (plantIdExistOrNot) {
                plantIdStatus();
            }
        })
            .catch(err => console.log(err));
    } else {
        plantIdStatus();
    };
    
});


router.patch('/update/:action/:userID', (req, res) => {

    if (req.params.action == 'stringInverter') {
        var data = {
            stringInverter: {
                isActive: true,
                quantity: req.body.data.length,
                details: req.body.data
            }
        }
    };

    if (req.params.action == 'centralizedInverter') {
        var data = {
            centralizedInverter: {
                isActive: true,
                quantity: req.body.data.length,
                details: req.body.data
            }
        }
    };

    if (req.params.action == 'weatherStation') {
        var data = {
            weatherStation: {
                isActive: true,
                quantity: req.body.data.length,
                details: req.body.data
            }
        }
    };

    if (req.params.action == 'meter') {
        var data = {
            meter: {
                isActive: true,
                quantity: req.body.data.length,
                details: req.body.data
            }
        }
    }

    if (req.params.action == 'dieselGenerator') {
        var data = {
            dieselGenerator: {
                isActive: true,
                quantity: req.body.data.length,
                details: req.body.data
            }
        }
    };

    if (req.params.action == 'dataLogger') {
        var data = {
            dataLogger: {
                isActive: true,
                quantity: req.body.data.length,
                details: req.body.data
            }
        }
    };

    Formdata.findByIdAndUpdate({ _id: req.params.userID }, { $set: data }, { new: true })
        .then(doc => {
            return res.json({ msg: 'Updated' });
        })
        .catch(err => console.log(err));
})

router.delete('/delete/:userID', (req, res) => {
    Formdata.findByIdAndDelete({ _id: req.params.userID })
        .then(doc => {
            res.status(202).json({
                success: true,
                message: 'Record deleted successfully'
            })
        }).catch(err => console.log(err))
})

router.post('/delete/:action/:userID', (req, res) => {

    if (req.params.action == 'stringInverter') {
        if (req.body.data.length == 0) {
            var data = {
                stringInverter: {
                    isActive: false,
                    quantity: req.body.data.length,
                    details: req.body.data
                }
            }
        } else {
            var data = {
                stringInverter: {
                    isActive: true,
                    quantity: req.body.data.length,
                    details: req.body.data
                }
            }
        }
    };

    if (req.params.action == 'centralizedInverter') {
        if (req.body.data.length == 0) {
            var data = {
                centralizedInverter: {
                    isActive: false,
                    quantity: req.body.data.length,
                    details: req.body.data
                }
            }
        } else {
            var data = {
                centralizedInverter: {
                    isActive: true,
                    quantity: req.body.data.length,
                    details: req.body.data
                }
            }
        }
    };

    if (req.params.action == 'weatherStation') {
        if (req.body.data.length == 0) {
            var data = {
                weatherStation: {
                    isActive: false,
                    quantity: req.body.data.length,
                    details: req.body.data
                }
            }
        } else {
            var data = {
                weatherStation: {
                    isActive: true,
                    quantity: req.body.data.length,
                    details: req.body.data
                }
            }
        }
    };

    if (req.params.action == 'meter') {
        if (req.body.data.length == 0) {
            var data = {
                meter: {
                    isActive: false,
                    quantity: req.body.data.length,
                    details: req.body.data
                }
            }
        } else {
            var data = {
                meter: {
                    isActive: true,
                    quantity: req.body.data.length,
                    details: req.body.data
                }
            }
        }
    }

    if (req.params.action == 'dieselGenerator') {
        if (req.body.data.length == 0) {
            var data = {
                dieselGenerator: {
                    isActive: false,
                    quantity: req.body.data.length,
                    details: req.body.data
                }
            }
        } else {
            var data = {
                dieselGenerator: {
                    isActive: true,
                    quantity: req.body.data.length,
                    details: req.body.data
                }
            }
        }
    };

    if (req.params.action == 'dataLogger') {
        if (req.body.data.length == 0) {
            var data = {
                dataLogger: {
                    isActive: false,
                    quantity: req.body.data.length,
                    details: req.body.data
                }
            }
        } else {
            var data = {
                dataLogger: {
                    isActive: true,
                    quantity: req.body.data.length,
                    details: req.body.data
                }
            }
        }
    };

    Formdata.findByIdAndUpdate({ _id: req.params.userID }, { $set: data }, { new: true })
        .then(doc => {
            return res.json({ msg: 'Deleted' });
        })
        .catch(err => console.log(err));

});


router.get('/all-data', (req, res) => {
    Formdata.find({})
        .then(document => {
            return res.status(200).json({ doc: document });
        })
        .catch(err => console.log(err))
})


router.get('/:id', (req, res) => {
    Formdata.findById({ _id: req.params.id })
        .then(document => {
            return res.status(200).json({ data: document })
        })
        .catch(err => console.log(err))
})


module.exports = router;