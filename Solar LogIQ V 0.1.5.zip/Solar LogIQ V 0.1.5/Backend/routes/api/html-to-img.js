const express = require('express');
const nodeHtmlToImage = require('node-html-to-image')
const fs = require('fs');
const { createCanvas, loadImage } = require('canvas');
const router = express.Router();


router.get('/new-img-test', (req, res) => {

  sldData = [
    
    {id: 1, inv: 'INV-1', kwp: '50 [kWp]', sId: '010 [S-ID]',
      liveGen: '2.39  kw  [Live Gen.]', kwh: '121284.500 [kwh]',
      date: '11/9/2020', time: '4:50 PM'
    },
  
    {id: 2,inv: 'INV-2', kwp: '50 [kWp]', sId: '011 [S-ID]',
    liveGen: '1.62  kw  [Live Gen.]', kwh: '78794.53 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
    },
  
      {id: 3,inv: 'INV-3', kwp: '50 [kWp]', sId: '012 [S-ID]',
      liveGen: '1.98  kw  [Live Gen.]', kwh: '84344.20 [kwh]',
      date: '11/9/2020', time: '4:50 PM'
    },
  
    {id: 4,inv: 'INV-4', kwp: '50 [kWp]', sId: '013 [S-ID]',
    liveGen: '1.9  kw  [Live Gen.]', kwh: '51951.50 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
    }, 
  
    {id: 5,inv: 'INV-5', kwp: '50 [kWp]', sId: '010 [S-ID]',
    liveGen: '1.06  kw  [Live Gen.]', kwh: '12568.5 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
    },

    {id: 6,inv: 'INV-6', kwp: '50 [kWp]', sId: '010 [S-ID]',
    liveGen: '1.06  kw  [Live Gen.]', kwh: '12568.5 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
    },

    {id: 7,inv: 'INV-7', kwp: '50 [kWp]', sId: '010 [S-ID]',
    liveGen: '1.06  kw  [Live Gen.]', kwh: '12568.5 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
    },

    {id: 8,inv: 'INV-8', kwp: '50 [kWp]', sId: '010 [S-ID]',
    liveGen: '1.06  kw  [Live Gen.]', kwh: '12568.5 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
    },

    {id: 9,inv: 'INV-9', kwp: '50 [kWp]', sId: '010 [S-ID]',
    liveGen: '1.06  kw  [Live Gen.]', kwh: '12568.5 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
    },

    {id: 10,inv: 'INV-10', kwp: '50 [kWp]', sId: '010 [S-ID]',
    liveGen: '1.06  kw  [Live Gen.]', kwh: '12568.5 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
    },

    {id: 11,inv: 'INV-11', kwp: '50 [kWp]', sId: '010 [S-ID]',
    liveGen: '1.06  kw  [Live Gen.]', kwh: '12568.5 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
    },

    {id: 12,inv: 'INV-12', kwp: '50 [kWp]', sId: '010 [S-ID]',
    liveGen: '1.06  kw  [Live Gen.]', kwh: '12568.5 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
    },

    {id: 13,inv: 'INV-13', kwp: '50 [kWp]', sId: '010 [S-ID]',
    liveGen: '1.06  kw  [Live Gen.]', kwh: '12568.5 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
    },

    {id: 14,inv: 'INV-14', kwp: '50 [kWp]', sId: '010 [S-ID]',
    liveGen: '1.06  kw  [Live Gen.]', kwh: '12568.5 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
    },

    {id: 15,inv: 'INV-15', kwp: '50 [kWp]', sId: '010 [S-ID]',
    liveGen: '1.06  kw  [Live Gen.]', kwh: '12568.5 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
    },

    {id: 16,inv: 'INV-16', kwp: '50 [kWp]', sId: '010 [S-ID]',
    liveGen: '1.06  kw  [Live Gen.]', kwh: '12568.5 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
    },
    
      
    ]
  
  var id = 0;
  const width = 2050;
  const height = 1400;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'green'
  ctx.fillRect(0, 0, width, height)

  for (var i = 0; i < 2; i++) {
    for (var j = 0; j < 8; j++) {
    id++;
  ctx.save();
     // Draw Vertical line
       ctx.beginPath();
       ctx.translate(50 + j * 250, 12 + i * 250);
       ctx.moveTo(10, 45);
       ctx.lineTo(10, 175);
       ctx.stroke();
       
       // Draw a rectangle Box
       ctx.beginPath();
       ctx.rect(-2, 175, 25, 25);
       ctx.stroke();
       
       // Draw a Cross line 
       ctx.beginPath();
       ctx.moveTo(-2, 200);
       ctx.lineTo(24, 175);
       
       ctx.moveTo(24, 200);
       ctx.lineTo(-2, 175);
       ctx.stroke();
       
       // Draw Vertical line after rectangle box
       ctx.beginPath();
       ctx.moveTo(10, 232);
       ctx.lineTo(10, 200);
       ctx.stroke();
     
       // Draw Arrow line 
       ctx.beginPath();
       ctx.moveTo(10, 233);
       ctx.lineTo(-2, 218);
       
       ctx.moveTo(10, 233);
       ctx.lineTo(23, 218);
       ctx.stroke();
       
       // Draw Horizontal Bottom line 
       ctx.beginPath();
       ctx.moveTo(0, 235);
       ctx.lineTo(250, 235);
        ctx.lineWidth = 2;
       ctx.stroke();

       // Dynamic Data Binding Secton
       sldData.forEach(element => {
         if(element.id == id){
        ctx.beginPath();
        ctx.font = 'bold 13px Britannic';
        ctx.fillStyle = 'white'
        ctx.textAlign = "start";
        ctx.fillText(element.inv, 35, 80);
        ctx.fillText(element.kwp, 35, 96);
        ctx.fillText(element.sId, 35, 112);
        ctx.fillStyle = 'red'
        ctx.fillText(element.liveGen, 35, 128);
        ctx.fillStyle = 'black'
        ctx.fillText(element.kwh, 35, 144);
                
		    ctx.fillStyle = 'blue'
        ctx.fillText(element.date, 35, 193);
        ctx.fillText(element.time, 35, 210);
        ctx.stroke();
         } 
       });

  ctx.restore();
}
}

 
  const buffer = canvas.toBuffer("image/png");
  fs.writeFileSync('./images/test20.png', buffer);
  res.send('<h2>Image created successfully! </h2>');
//*********************************************************************************************************************************************/


});


router.get('/old-img-test', (req, res) => {

  const width = 1200;
  const height = 600;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = 'green'
  ctx.fillRect(0, 0, width, height)

  var recBox = false;
  var id = 0;
  for(var a = 70; a < 1000; a +=200){
    id++;
    if(recBox){
        rectangleBox = a - 12;
        crossLine1 = a - 12;
        crossLine2 = a + 13;
        arroLine1 = a; 
        arroLine2 = a + 15;
        arroLine3 = a - 15;
        textAlign = a + 20;
        
    }else{
    	  rectangleBox = 57;
        crossLine1 = 82;
        crossLine2 = 57;
        arroLine1 = 70;
        arroLine2 = 85;
        arroLine3 = 56;
        textAlign = 90;
    }
 	
	drawDesign(a, ctx, rectangleBox, crossLine1, crossLine2, arroLine1, arroLine2, arroLine3, textAlign, id);
  
}

 function  drawDesign(a, ctx, rectangleBox, crossLine1, crossLine2, arroLine1, arroLine2, arroLine3, textAlign, id) {
    recBox = true;

  arrayData = [
    
  {id: 1, inv: 'INV-1', kwp: '50 [kWp]', sId: '010 [S-ID]',
    liveGen: '2.39  kw  [Live Gen.]', kwh: '121284.500 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
  },

  {id: 2,inv: 'INV-2', kwp: '50 [kWp]', sId: '011 [S-ID]',
  liveGen: '1.62  kw  [Live Gen.]', kwh: '78794.53 [kwh]',
  date: '11/9/2020', time: '4:50 PM'
  },

    {id: 3,inv: 'INV-3', kwp: '50 [kWp]', sId: '012 [S-ID]',
    liveGen: '1.98  kw  [Live Gen.]', kwh: '84344.20 [kwh]',
    date: '11/9/2020', time: '4:50 PM'
  },

  {id: 4,inv: 'INV-4', kwp: '50 [kWp]', sId: '013 [S-ID]',
  liveGen: '1.9  kw  [Live Gen.]', kwh: '51951.50 [kwh]',
  date: '11/9/2020', time: '4:50 PM'
  }, 

  {id: 5,inv: 'INV-5', kwp: '50 [kWp]', sId: '010 [S-ID]',
  liveGen: '1.06  kw  [Live Gen.]', kwh: '12568.5 [kwh]',
  date: '11/9/2020', time: '4:50 PM'
  }
    
  ]

//  var  data = ''
  arrayData.forEach(element => {
    //  console.log(element)
      if(element.id == id ) {
        ctx.beginPath();
        ctx.font = 'bold 13px Britannic';
        ctx.fillStyle = 'white'
        ctx.textAlign = "start";
        ctx.fillText(element.inv, textAlign, 80);
        ctx.fillText(element.kwp, textAlign, 96);
        ctx.fillText(element.sId, textAlign, 112);
        ctx.fillText(element.liveGen, textAlign, 128);
        ctx.fillText(element.kwh, textAlign, 144);
        ctx.fillText(element.date, textAlign, 193);
        ctx.fillText(element.time, textAlign, 210);
        ctx.stroke();
      }
    });


    // Draw Vertical line
    ctx.beginPath();
    ctx.moveTo(a, 70);
    ctx.lineTo(a, 190);
    ctx.stroke();
    
    // Draw a rectangle Box
    ctx.beginPath();
    ctx.rect(rectangleBox, 190, 25, 25);
    ctx.restore();
    ctx.stroke();
    
     // Draw a Cross line 
    ctx.beginPath();
    ctx.moveTo(crossLine1, 215);
    ctx.lineTo(crossLine2, 190);
    
    ctx.moveTo(crossLine2, 215);
    ctx.lineTo(crossLine1, 190);
    ctx.stroke();
    
    // Draw Vertical line after rectangle box
    ctx.beginPath();
    ctx.moveTo(a, 245);
    ctx.lineTo(a, 215);
    ctx.stroke();
    
    // Draw a Arrow line 
    ctx.beginPath();
    ctx.moveTo(arroLine1, 245);
    ctx.lineTo(arroLine2, 230);
    
    ctx.moveTo(arroLine1, 245);
    ctx.lineTo(arroLine3, 230);
    ctx.stroke();
    
    // Draw a Horizontal Bottom line 
    ctx.beginPath();
    ctx.moveTo(50,246);
    ctx.lineTo(1200,246);
    // ctx.lineWidth = 3;
    ctx.stroke();
    
  }
 
  const buffer = canvas.toBuffer("image/png");
  fs.writeFileSync('./images/test6.png', buffer);
  res.send('<h2>Image created successfully! </h2>');
//*********************************************************************************************************************************************/


  // ctx.rotate(45 * Math.PI / 180);
  // ctx.fillStyle = 'red';
  // ctx.fillRect(100, 0, 80, 20);
//   let data = 'Dummy name';
//   let number = 125
//   const data2 = `Hello world ${data}: Dummy number ${number}`

// ctx.font = '30px serif';
// ctx.fillText = "#fff";

// ctx.beginPath();
// ctx.moveTo(20, 20);
// ctx.lineTo(20, 100);
// ctx.lineTo(70, 100);
// ctx.stroke();

// ctx.fillText(data2, 50, 90);

  
  // for (var i = 0; i < 3; i++) {
  //   for (var j = 0; j < 3; j++) {
  //     ctx.save();
  //     ctx.fillStyle = 'rgb(' + (51 * i) + ', ' + (255 - 51 * i) + ', 255)';
  //     ctx.translate(10 + j * 50, 10 + i * 50);
  //     ctx.fillRect(0, 0, 25, 25);
  //     ctx.restore();
  //   }
  // }


// for(let i = 0; i<=4; i++){
//   console.log('***************')
//   ctx.beginPath();
//   ctx.moveTo(75, 25);
//   ctx.quadraticCurveTo(25, 25, 25, 62.5);
//   ctx.quadraticCurveTo(25, 100, 50, 100);
//   ctx.quadraticCurveTo(50, 120, 30, 125);
//   ctx.quadraticCurveTo(60, 120, 65, 100);
//   ctx.quadraticCurveTo(125, 100, 125, 62.5);
//   ctx.quadraticCurveTo(125, 25, 75, 25);
//   ctx.stroke();
// }



//   // Non-rotated rectangle
// ctx.fillStyle = 'gray';
// ctx.fillRect(80, 60, 140, 30);

// // Matrix transformation
// ctx.translate(150, 75);
// ctx.rotate(Math.PI / 2);
// ctx.translate(-150, -75);

// // Rotated rectangle
// ctx.fillStyle = 'red';
// ctx.fillRect(80, 60, 140, 30);



  // ctx.font = '50px Impact'
  // ctx.rotate(0, 0)
  // ctx.fillText('Awesome!', 90, 50)

  // ctx.fillText = "#fff";
  // ctx.fillRect(0, 0, width, height);


  // var text = ctx.measureText('Awesome!')
  // ctx.strokeStyle = 'rgba(0,0,0,0.5)'
  // ctx.beginPath()
  // ctx.lineTo(50, 102)
  // ctx.lineTo(50 + text.width, 102)
  // ctx.stroke()

// var text = ctx.measureText('Awesome')
// ctx.strokeStyle = 'rgba(0,0,0,0.5)'
// ctx.beginPath()
// ctx.lineTo(30, 102)
// ctx.lineTo(30 + text.width, 102)
// ctx.stroke()
  

  // loadImage('./images/img.png').then(image => {
  //   console.log(image)
  //   // return
  //   ctx.drawImage(image, 50, 0, 70, 70)
  //   const buffer = canvas.toBuffer('image/png')
  //   fs.writeFileSync('./test.png', buffer)
  // })

});







router.get('/dummy', (req, res) => {
    let fileData = `
    <html>
    <head>
      <style>
        body {
        border-top: 2px solid yellow;    
        background: #000000;
          color: #FFFFFF;
        }
        .arrow {
            border: solid white;
            border-width: 0 3px 3px 0;
            display: inline-block;
            padding: 3px;
          }
        .right {
        transform: rotate(-45deg);
        
        }  

        #myCanvas{
            color: #FFFFFF;
        }

      </style>
    </head>

    <body>
           <h3>USER :<span>A P Goyal University </span> </h3>
           <h3>Plant Capacity: <span>200 KWP </span> </h3>
           <h3>Plant Location <span>SHIMLA </span> </h3>
           <p>Right arrow: <i class="arrow right"></i></p>

           <canvas id="myCanvas" width="200" height="100" style="border:1px solid #d3d3d3;"> </canvas>


          var c = document.getElementById("myCanvas");
          var ctx = c.getContext("2d");
          ctx.moveTo(0,0);
          ctx.lineTo(200,100);
          ctx.stroke();
                   
    </body>
    </html>
    `

    nodeHtmlToImage({
        output: './images/img.png',
        html: fileData
      })
    .then(() => res.json({message: 'The image was created successfully!'}))
    .catch(err => console.log(err))
});

module.exports = router;




