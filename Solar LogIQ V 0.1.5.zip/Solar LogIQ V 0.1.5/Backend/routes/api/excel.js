const express = require('express');
const router = express.Router();
const Excel = require('exceljs');



router.get('/create-excel', async (req, res) => {
    const workbook = new Excel.Workbook();
     workbook.addWorksheet('My Sheet 1');
     workbook.addWorksheet('My Sheet 2');
     workbook.addWorksheet('My Sheet 3');

    workbook.eachSheet(function(worksheet1, sheetId) {
        const imageId1 = workbook.addImage({
            filename: './images/icon.png',
            extension: 'png',
        });
    
        worksheet1.addImage(imageId1, 'A1:E6');
    
        worksheet1.mergeCells('F1:J2');
        worksheet1.mergeCells('K1:O2');
        worksheet1.mergeCells('P1:T2');
    
        worksheet1.getCell('H1').value = 'Holmium Technology!';
        worksheet1.getCell('M1').value = 'Term Condition';
        worksheet1.getCell('R1').value = 'Client Name';
    
        worksheet1.getCell('H1').alignment = { vertical: 'middle', horizontal: 'center' }
        worksheet1.getCell('M1').alignment = { vertical: 'middle', horizontal: 'center' }
        worksheet1.getCell('R1').alignment = { vertical: 'middle', horizontal: 'center' }
    
        function getCell_Front(cellValue, size, color) {
            worksheet1.getCell(cellValue).font = {
                size: size,
                color: { argb: color },
                bold: true,
            };
        };
    
        getCell_Front('H1', 16, 'FFFFFFFF');
        getCell_Front('M1', 16, 'FFFFFFFF');
        getCell_Front('R1', 16, 'FFFFFFFF');
    
        function getCell_Fill(cellValue, type, pattern, color) {
            worksheet1.getCell(cellValue).fill = {
                type: type,
                pattern: pattern,
                fgColor: { argb: color }
            };
        };
    
        getCell_Fill('F1', 'pattern', 'solid', 'FF0000FF');
        getCell_Fill('K1', 'pattern', 'solid', 'FF0000FF');
        getCell_Fill('P1', 'pattern', 'solid', 'FF0000FF');
    
    });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    // res.setHeader("Content-Disposition", "attachment; filename=" + 'holmium_report.xlsx');
    // res.setHeader({success: true})
    await workbook.xlsx.write(res).then(data => {
        // res.sendFile(res)
        // res.json({success: true})
        res.end();
    }).catch(err => {
        console.log(err)
    })
    // res.json({success: true})
});


module.exports = router;




// https://tdev.app/ngx-ui-loader

// https://firstclassjs.com/display-a-loader-on-every-http-request-using-interceptor-in-angular-7/

// https://stackoverflow.com/questions/52356324/display-spinner-till-api-response-in-angular-6

// https://morioh.com/p/5476b5489d71

// https://www.freakyjolly.com/http-global-loader-progress-bar-using-angular-interceptors/#.XwvquXUzbJx

// https://www.techiediaries.com/angular/angular-9-8-tutorial-by-example-rest-crud-apis-http-get-requests-with-httpclient/

