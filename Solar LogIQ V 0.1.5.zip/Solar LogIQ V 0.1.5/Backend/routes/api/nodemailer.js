const express = require('express');
const nodemailer = require('nodemailer')
const router = express.Router();


router.get('/send-email', async (req, res) => {

    let transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 465,
        secure: true,
        auth: {
          user: 'holmium.emonitoring@gmail.com', 
          pass: 'Holmium@monitoring1', 
        },
      });

      let info = await transporter.sendMail({
        from:  "holmiumtechnologies18@gmail.com", 
        to:'amitkumarpstc24@gmail.com',
        subject: "Hello ✔", 
        html: `
        <h1>Hello Gmail</h1>
        <h2>Hello Gmail</h2>
        <h3>Hello Gmail</h3>
        <h4>Hello Gmail</h4>
        <h5>Hello Gmail</h5>
        <h6>Hello Gmail</h6>
        `
      });
      res.send('<h2>Email send successfully..</h2>')
});

module.exports = router;