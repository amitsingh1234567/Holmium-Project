const express = require('express');
const https = require('https');
const fs = require('fs');
const bodyparser = require('body-parser');
const mongoose = require('mongoose');
const key = require('./mongoDb-key/key').MongoURI
const session = require('express-session');
const mongoDb_Store_Session = require('connect-mongodb-session')(session);
const cors = require('cors');
const app = express();



// const store = new mongoDb_Store_Session({
//   uri: key,
//   collection: 'mypeople2',
//   ttl: 0 * 0 * 60 * 0
// });



// Connect to Mongo
// mongoose.connect(key, { useNewUrlParser: true, useUnifiedTopology: true, useFindAndModify: false })
// .then(() => console.log('MongoDb Connected Successfully...'))
// .catch(err => console.log('Connection problem in mongoDb ', err));

// Cors
app.use(cors({
  origin:'http://localhost:4200',
}));    

// Bringing All Routes 
const user = require('./routes/api/auth');
const excel = require('./routes/api/excel');
const nodemailer = require('./routes/api/nodemailer');
// const formdata = require('./routes/api/formdata');
const html_to_img = require('./routes/api/html-to-img');

app.get('/dummy', (req, res) => {
  console.log('*****************')
 return res.json({success: true})
})

// var session1 = session({
//   secret: 'myStront_Secret',
//   store: store
// });

// Session Config
// app.use(session({
//   secret: 'myStront_Secret',
//   resave: true, 
//   saveUninitialized: true,
//   token:'',
//   user_id:'',
//   store: store
// }));

// Config Body-Parser
app.use(bodyparser.urlencoded({ extended: false }));
app.use(bodyparser.json());

// Actual route
app.use('/api/users', user);
app.use('/api/excel', excel);
app.use('/api/nodemailer', nodemailer);
// app.use('/api/formdata', formdata);
app.use('/api/html-to-img', html_to_img);



const options = {
    key: fs.readFileSync('privatekey.pem'),
    cert: fs.readFileSync('certificate.pem'),
  };

const server = https.createServer(options, app);

const io = require('socket.io').listen(server);

io.sockets.on('connection', socket => {
  // console.log(socket)
  // console.log('A user Connected');

  socket.emit('hello',{greeting: 'From Server...'});

  socket.on('getData', data => {
    // console.log(data);
  })
});

server.listen(3000,() => console.log(`Server running on port:3000`));