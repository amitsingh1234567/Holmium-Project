const mongoose = require('mongoose');
const Schema = mongoose.Schema;


const plantSchema = new Schema({
    plantId:{type: Number},
    plantName:{type: String},
    flag:
       {
        dashboard: Boolean,
         analytic: Boolean,
         meter: Boolean,
         inverter: Boolean,
         wms: Boolean,
         alarm: Boolean,
         dataExport: Boolean,
     
     }
})

module.exports = plantModel = mongoose.model('plantName', plantSchema);







