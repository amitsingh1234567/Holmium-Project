const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const personSchema = new Schema({
    
    email:{
        type: String,
        required: true
    },
    password:{
        type: String,
        required: true
    },
    plantId:{
        type:[Object],
        
    },
    session:{
        type:Object
    }
})

module.exports = User = mongoose.model('myPerson', personSchema);
