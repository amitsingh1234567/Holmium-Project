const mongoose = require('mongoose');

const formdataSchema = new mongoose.Schema({
    plantId:{
        type: Number,
        // required: true
    },
    plantName:{
        type: String,
        // required: true
    },
    location:{
        type: Object,
        // required: true
    },
    commissioningDate: {
        type: Date,
        // required: true,
    },
    licenseExpiryDate: {
        type: Date,
        // required: true,
    },
    owner: {
        type: String,
        // required: true,
    },
    emailId: {
        type: Object,
        // required: true,
    },
    mobileNo: {
        type: Object,
        // required: true
    },
    unitPrice: {
        type: Number,
    },
    plantCapacity: {
        type: Number,
        // required: true 
    },
    PVModules: {
        type: Object
    },
    stringInverter: {
        type: Object,
        // required: true
    },
    centralizedInverter: {
        type: Object,
        // required: true
    },
    weatherStation: {
        type: Object,
        // required: true
    },
    meter: {
        type: Object,
        // required: true

    },
    dieselGenerator: {
        type: Object,
        // required: true
    },
    dataLogger: {
        type: Object,
        // required: true
    }

});

module.exports = formdataModel = mongoose.model('userData', formdataSchema);

