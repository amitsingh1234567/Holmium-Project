import { Injectable } from "@angular/core";
import { HttpClient, HttpParams } from "@angular/common/http";
import { Subject, throwError, Observable } from "rxjs";
import { Router } from "@angular/router";

export interface Response {
    status: boolean, 
    message: string, 
    response: any
}

@Injectable({ providedIn: "root" })
export class ComponentsService {  

  constructor(private http: HttpClient, private router: Router ) {}

  getSiteNavigation(username:string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/site/navigation?username="+username+"&siteid="+siteId)
  }

  getUserProfile(username: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/user/profile?username="+username)
  }

  getAlarmNotification(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/alarm/notification?username="+username+"&siteid="+siteId)
  }

}