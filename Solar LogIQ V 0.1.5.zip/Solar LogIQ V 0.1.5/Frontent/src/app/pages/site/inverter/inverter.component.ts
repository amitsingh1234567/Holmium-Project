import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import HC_exporting from 'highcharts/modules/exporting';
import { from } from 'rxjs';
import { SiteService } from '../site.service'

@Component({
  selector: 'app-inverter',
  templateUrl: './inverter.component.html',
  styleUrls: ['./inverter.component.scss']
})
export class InverterComponent implements OnInit {
  chartOptions = {};
  highcharts = Highcharts;
  bsDate = new Date();
  invDropdownDate = [
    {id: 1, name: 'Inverter-1'},
    {id: 2, name: 'Inverter-2'},
    {id: 3, name: 'Inverter-3'},
    {id: 4, name: 'Inverter-4'},
    {id: 5, name: 'Inverter-5'},
    {id: 6, name: 'Inverter-6'},
  ]
  
  constructor(private siteService: SiteService) { }

  ngOnInit(): void {
    this.lineChart();
  }

  onSelect(event) {
    console.log(event)
  };

  onDateValueChange(value: Date): void {
    console.log(value)
  }

  lineChart() {
    this.chartOptions = {
      chart: {
        type: 'line',
        backgroundColor: '#343a40'
      },

      title: {
        text: null
      },

      subtitle: {
        text: null
      },

      legend: {
        itemStyle: {
           color: '#FFFFFF'
        },
        itemHoverStyle: {
           color: '#FFF'
        },
        itemHiddenStyle: {
           color: '#444'
        }
  },
      
      xAxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        labels: {
          style: {
            color: '#FFFFFF'
          }
        },
      },

      yAxis: {
        title: {
          text: 'Temperature (°C)',
          style: {
            color: '#FFFFFF'
          }
        },
        labels: {
          style: {
            color: '#FFFFFF'
          }
        },
      },

      credits: {
        enabled: false
      },

      tooltip: {
        crosshairs: true,
        shared: true,
        // valuePrefix: '$'
      },

      plotOptions: {
        // line: {
        //   dataLabels: {
        //     enabled: true
        //   },
        //   enableMouseTracking: false
        // }
        series: {
          label: {
              connectorAllowed: false
          },
          // pointStart: 2010
      }
      },

      series: [{
        name: 'Tokyo',
        data: [7.0, 6.9, 9.5, 14.5, 18.4, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
      }, {
        name: 'London',
        color: '#FFA500',
        data: [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 10.3, 6.6, 4.8]
      }]
    }
    HC_exporting(Highcharts);
  }

}
