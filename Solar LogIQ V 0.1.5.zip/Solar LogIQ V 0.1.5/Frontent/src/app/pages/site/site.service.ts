import { Injectable } from "@angular/core";
// import {Http, ResponseContentType} from '@angular/http';
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Subject, throwError, Observable, BehaviorSubject } from "rxjs";

import { Router, ActivatedRoute } from "@angular/router";

import { Response } from "./site.model";
import { tap } from 'rxjs/operators';
// import { ResponseContentType } from '@angular/http/src';
// import { ResponseContentType } from '@angular/http/src/enums';

@Injectable({ providedIn: "root" })
export class SiteService {

  private pathParamState = new Subject<string>();
  pathParam: Observable<string>;
  public siteId: string;

  constructor(private http: HttpClient, private router: Router, private route: ActivatedRoute) {
    this.pathParam = this.pathParamState.asObservable();
  }

  downloadExcelSheet():Observable<any>{
    return this.http.get('https://localhost:3000/api/excel/create-excel',
      {
        headers: new HttpHeaders({
          'content-type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        }), responseType: 'blob'
      })
  };

  updatePathParamState(newPathParam: string) {
    this.pathParamState.next(newPathParam);
  }

  async getSiteId() {
    await this.pathParam.subscribe(site => this.siteId = site);
    return this.siteId;
  }

  getSiteDevices(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/site/devices?username="
      + username + "&siteid=" + siteId)
  }

  getSiteNavigation(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/site/navigation?username=" + username + "&siteid=" + siteId)
  }

  getDashboardCard(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/dashboard/card?username=" + username + "&siteid=" + siteId)
  }

  getDashboardSiteLevelStatus(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/dashboard/status?username=" + username + "&siteid=" + siteId)
  }

  getDashboardCurve(username: string, siteId: string, period: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/dashboard/curve?username="
      + username + "&siteid=" + siteId + "&period=" + period)
  }

  getAnalyticsCurve1(username: string, siteId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/analytics/curve1?username="
      + username + "&siteid=" + siteId + "&timestamp=" + timestamp)
  }

  getAnalyticsCurve2(username: string, siteId: string, period: string, timestamp: any): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/analytics/curve2?username="
      + username + "&siteid=" + siteId + "&period=" + period + "&timestamp=" + timestamp)
  }
  getAnalyticsCurve3(username: string, siteId: string, timestamp: string, deviceId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/analytics/curve3?username="
      + username + "&siteid=" + siteId + "&timestamp=" + timestamp + "&deviceid=" + deviceId)
  }

  getAnalyticsCurve4(username: string, siteId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/analytics/curve4?username="
      + username + "&siteid=" + siteId + "&timestamp=" + timestamp)
  }

  getStringInverterCard(username: string, siteId: string, deviceId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/inverter/stringInverterCard?username="
      + username + "&siteid=" + siteId + "&deviceid=" + deviceId)
  }

  getStringInverterCurve(username: string, siteId: string, deviceId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/inverter/stringInverterCurve?username="
      + username + "&siteid=" + siteId + "&deviceid=" + deviceId + "&timestamp=" + timestamp)
  }

  getWeatherStationCard(username: string, siteId: string, deviceId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/weatherstation/card?username="
      + username + "&siteid=" + siteId + "&deviceid=" + deviceId)
  }

  getWeatherStationCurve1(username: string, siteId: string, deviceId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/weatherstation/Curve1?username="
      + username + "&siteid=" + siteId + "&deviceid=" + deviceId + "&timestamp=" + timestamp)
  }

  getWeatherStationCurve2(username: string, siteId: string, deviceId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/weatherstation/Curve2?username="
      + username + "&siteid=" + siteId + "&deviceid=" + deviceId + "&timestamp=" + timestamp)
  }

  getAlarmDetail(username: string, siteId: string, device: string, state: string, timestamp: number): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/alarm/detail?username="
      + username + "&siteid=" + siteId + "&device=" + device + "&state=" + state + "&timestamp=" + timestamp)
  }

  getInformationCard(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/information/card?username="
      + username + "&siteid=" + siteId)
  }

  getInformationProfile(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/information/profile?username="
      + username + "&siteid=" + siteId)
  }
}
