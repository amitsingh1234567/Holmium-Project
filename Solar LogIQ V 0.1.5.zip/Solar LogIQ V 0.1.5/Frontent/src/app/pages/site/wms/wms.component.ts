import { Component, OnInit, OnDestroy } from "@angular/core";

import * as _moment from 'moment';
import 'moment/locale/en-in';

import * as Highcharts from 'highcharts';
import HC_exporting from 'highcharts/modules/exporting';



@Component({
  selector: "app-wms",
  templateUrl: "wms.component.html",
  styleUrls: ['./wms.component.scss'],
})
export class WmsComponent implements OnInit, OnDestroy {
  
  chartOptions = {};
  highcharts = Highcharts;
  bsDate = new Date();
  wmsDropdownDate = [
    {id: 1, name: 'wms-1'},
    {id: 2, name: 'wms-2'},
    {id: 3, name: 'wms-3'},
    {id: 4, name: 'wms-4'},
    {id: 5, name: 'wms-5'},
    {id: 6, name: 'wms-6'},
  ]

  ngOnInit(){
  this.lineChart();
  };

  onSelect(event): void {
    console.log(event)
  };

  onDateValueChange(value: Date): void {
    console.log(value)
  }

  lineChart() {
    this.chartOptions = {
      chart: {
        type: 'line',
        backgroundColor: '#343a40'
      },

      title: {
        text: null
      },

      subtitle: {
        text: null
      },

      legend: {
        itemStyle: {
           color: '#FFFFFF'
        },
        itemHoverStyle: {
           color: '#FFF'
        },
        itemHiddenStyle: {
           color: '#444'
        }
  },
      
      xAxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        labels: {
          style: {
            color: '#FFFFFF'
          }
        },
      },

      yAxis: {
        title: {
          text: 'Temperature (°C)',
          style: {
            color: '#FFFFFF'
          }
        },
        labels: {
          style: {
            color: '#FFFFFF'
          }
        },
      },

      credits: {
        enabled: false
      },

      tooltip: {
        crosshairs: true,
        shared: true,
        // valuePrefix: '$'
      },

      plotOptions: {
        // line: {
        //   dataLabels: {
        //     enabled: true
        //   },
        //   enableMouseTracking: false
        // }
        series: {
          label: {
              connectorAllowed: false
          },
          // pointStart: 2010
      }
      },

      series: [{
        name: 'Tokyo',
        color: '#FFA500',
        data: [7.0, 6.9, 9.5, 14.5, 18.4, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
      }, {
        name: 'London',
        color: '#50FF50',
        data: [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 10.3, 6.6, 4.8]
      }]
    }
    HC_exporting(Highcharts);
  }



ngOnDestroy(){

}
  
};
    