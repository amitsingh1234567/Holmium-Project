import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ComponentsModule } from "../../components/components.module";
// import { ScrollingModule } from '@angular/cdk/scrolling'

import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatButtonModule } from '@angular/material/button';
import { MatTabsModule } from '@angular/material/tabs';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import {MatIconModule} from '@angular/material/icon';


import { BsDropdownModule } from "ngx-bootstrap";
import { ProgressbarModule } from "ngx-bootstrap/progressbar";
import { TooltipModule } from "ngx-bootstrap/tooltip";
import { ModalModule } from "ngx-bootstrap/modal";
import { TabsModule } from 'ngx-bootstrap/tabs';

import { HighchartsChartModule } from 'highcharts-angular';

import { DashboardComponent } from "./dashboard/dashboard.component";
import { AnalyticsComponent } from "./analytics/analytics.component";
import { StringInverterComponent } from "./stringinverter/stringinverter.component";
import { WmsComponent } from "./wms/wms.component";
import { MeterComponent } from "./meter/meter.component";
import { PV_DGSyncComponent } from "./pv-dgsync/pv-dgsync.component";
import { ZeroExportComponent } from "./zeroexport/zeroexport.component";
import { AlarmComponent } from "./alarm/alarm.component";
import { ReportComponent } from "./report/report.component";
import { CalendarComponent } from "./calendar/calendar.component";
import { InformationComponent } from "./information/information.component";

import { DatepickerModule } from "../../datepicker/datepicker.module";
//import { Datepicker1Component } from "../../datepicker/DatePicker1/datepicker1.component";
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { RouterModule } from "@angular/router";
import { SiteRoutes } from "./site.routing";
import { HomeComponent } from './home/home.component';
import { InverterComponent } from './inverter/inverter.component';
import { ScbComponent } from './scb/scb.component';
import { from } from 'rxjs';


@NgModule({
  declarations: [
    DashboardComponent,
    AnalyticsComponent,
    StringInverterComponent,
    WmsComponent,
    MeterComponent,
    PV_DGSyncComponent,
    ZeroExportComponent,
    AlarmComponent,
    AlarmComponent,
    ReportComponent,
    CalendarComponent,
    InformationComponent,
    HomeComponent,
    InverterComponent,
    ScbComponent
],
  imports: [
    CommonModule,
    ComponentsModule,
    FormsModule,
    ReactiveFormsModule,
    BsDropdownModule.forRoot(),
    ModalModule.forRoot(),
    ProgressbarModule.forRoot(),
    TooltipModule.forRoot(),
    TabsModule.forRoot(),
    RouterModule.forChild(SiteRoutes),
    BsDatepickerModule.forRoot(),
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatButtonModule,
    MatTabsModule,
    MatIconModule,
    MatMomentDateModule,
    HighchartsChartModule,
    DatepickerModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
  ],
  exports: [
    DashboardComponent,
    AnalyticsComponent,
    StringInverterComponent,
    WmsComponent,
    MeterComponent,
    PV_DGSyncComponent,
    ZeroExportComponent,
    AlarmComponent,
    AlarmComponent,
    ReportComponent,
    CalendarComponent,
    InformationComponent,
    HomeComponent,
    InverterComponent,
    ScbComponent
  ]
})
export class SiteModule { }
