import { Component, OnInit, OnDestroy, AfterViewInit } from "@angular/core";
import { ActivatedRoute } from '@angular/router';
// import {Howl, Howler} from 'howler';
import { Howl, } from 'howler'

import { SiteService } from '../site.service';
import { takeUntil, map } from 'rxjs/operators';
import { from, Subject } from 'rxjs';

// import { } from  '../../../../assets/songs'

@Component({
  selector: "app-zeroexport",
  templateUrl: "zeroexport.component.html",
  styleUrls: ['./zeroexport.component.scss'],
})
export class ZeroExportComponent implements OnInit, OnDestroy, AfterViewInit {
  
  sound;
  isActiveLED 
  isActive = true
  btnText = 'Turn OFF now'
  onBtnAction = true;
  onBtnActn = true
  private destroy = new Subject<void>();

  constructor( private route: ActivatedRoute, private siteService: SiteService) {
   
    // https://github.com/goldfire/howler.js/issues/1028

    // this.sound = new Howl({
    //   src: ['assets/songs/audio.mp3'],
    //   loop: true,
    //   volume: 0.5,
    //   // html5: true,
    //   // onend: function() {
    //   //   console.log('Finished!!')
    //   // }
    // });
    // this.sound.play();
  }

  startAlarm(){
    this.sound = new Howl({
      src: ['assets/songs/audio.mp3'],
      loop: true,
      volume: 0.5,
    });
    this.sound.play();
  }


  stopAlarm(){
    this.sound.stop();
  }

  ngAfterViewInit(){
    // var audio = new Audio();
    // audio.src = '../../../../assets/songs/gojek-grab.mp3';
    // audio.load();
    // audio.play();
  }

  ngOnInit() {
    
    setInterval(() => {
      // let isActive = true
      if(this.isActive){
        this.isActiveLED = true;
        this.isActive = false;
      }else{
        this.isActiveLED = false;
       this.isActive = true;
      }
    }, 500)

  
  }

  onAction(){
    if(this.onBtnActn){
      this.btnText = 'Turn ON now'
      this.onBtnAction = false
      this.onBtnActn = false;
    }else{
      this.btnText = 'Turn OFF now';
      this.onBtnActn = true;
      this.onBtnAction = true;
    }
  }

  ngOnDestroy() {
    // this.destroy.next();
    // this.destroy.complete();
    // this.siteService.updatePathParamState(null);
   }
}
