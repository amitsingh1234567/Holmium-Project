import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import HC_exporting from 'highcharts/modules/exporting';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  chartOptions1: {};
  chartOptions2: {};
  data1 = [
    ['Shanghai', 24.2],
    ['Beijing', 20.8],
    ['Karachi', 14.9],
    ['Shenzhen', 13.7],
    ['Guangzhou', 13.1],
    ['Istanbul', 12.7],
    ['Mumbai', 12.4],
    ['Moscow', 12.2],
    ['São Paulo', 12.0],
    ['Delhi', 11.7],
    ['Kinshasa', 11.5],
    ['Tianjin', 11.2],
    ['Lahore', 11.1],
    ['Jakarta', 10.6],
    ['Dongguan', 10.6],
    ['Lagos', 10.6],
    ['Bengaluru', 10.3],
    ['Seoul', 9.8],
    ['Foshan', 9.3],
    ['Tokyo', 9.3]
  ];
  

  highcharts1 = Highcharts;
  highcharts2 = Highcharts;
  constructor() { };

  ngOnInit(): void {
    console.log('Home.......')
    this.chart1();
    this.chart2();
  };

  chart1(){
    this.chartOptions1 = {
      chart: {
        type: 'column',
        backgroundColor: '#343a40',        
      },
      title: false,
      subtitle: false,
      xAxis: {
        type: 'category',
        labels: {
        rotation: -45,
        style: {
          fontSize: '13px',
          fontFamily: 'Verdana, sans-serif',
          color: '#efefef'
          }
        }
      },
      yAxis: {
        min: 0,
        title: false,
        labels: {
          style: {
            color: '#FFFFFF'
          }
        },
      },
      credits: {
        enabled: false
      },
      legend: {
        enabled: false
      },
      tooltip: {
        pointFormat: 'Population in 2017: <b>{point.y:.1f} millions</b>',
      },

      series: [{
        name: 'Population',
        color: '#20c997',
        data: this.data1,

        dataLabels: {
          enabled: true,
          rotation: -90,
          color: '#FFFFFF',
          align: 'right',
          format: '{point.y:.1f}', // one decimal
          y: 10, // 10 pixels down from the top
          style: {
            fontSize: '13px',
            fontFamily: 'Verdana, sans-serif'
          }
        }
      }]
    }
    HC_exporting(Highcharts);
  };

  chart2(){
    this.chartOptions2 = {
      chart: {
        type: 'column',
        backgroundColor: '#343a40'        
      },
      legend: {
        itemStyle: {
           color: '#FFFFFF'
        },
        itemHoverStyle: {
           color: '#FFF'
        },
        itemHiddenStyle: {
           color: '#444'
        }
  },
      title: {
        text: null,
      },
      subtitle: false,
      credits: {
        enabled: false
      },
      xAxis: {
        categories: [
            'Jan',
            'Feb',
            'Mar',
            'Apr',
            'May',
            'Jun',
            'Jul',
            'Aug',
            'Sep',
            'Oct',
            'Nov',
            'Dec'
        ],
        labels: {
          style: {
            color: '#FFFFFF'
          }
        },
        crosshair: true,        
    },
    yAxis: {
      min: 0,
      title: null,
      labels: {
        style: {
          color: '#FFFFFF'
        }
      },
  },
  tooltip: {
    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
    pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
        '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
    footerFormat: '</table>',
    shared: true,
    useHTML: true
},
plotOptions: {
  column: {
      pointPadding: 0.2,
      borderWidth: 0,
  }
},

series: [
  {
  name: 'Tokyo',
  data: [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4], 
  // showInLegend: false 
}, {
  name: 'New York',
  data: [83.6, 78.8, 98.5, 93.4, 106.0, 84.5, 105.0, 104.3, 91.2, 83.5, 106.6, 92.3],
  // showInLegend: false

}, {
  name: 'London',
  data: [48.9, 38.8, 39.3, 41.4, 47.0, 48.3, 59.0, 59.6, 52.4, 65.2, 59.3, 51.2],
  // showInLegend: false
}, {
  name: 'Berlin',
  data: [42.4, 33.2, 34.5, 39.7, 52.6, 75.5, 57.4, 60.4, 47.6, 39.1, 46.8, 51.1],
  // showInLegend: false
},
]

  }
  HC_exporting(Highcharts);
}

}
