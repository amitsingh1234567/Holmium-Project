import { Component, OnInit, OnDestroy, ViewChild } from "@angular/core";
import { ActivatedRoute, ParamMap, Router  } from '@angular/router';

import { takeUntil, map, startWith, switchMap } from 'rxjs/operators';
import { Subject, Subscription, interval, Observable } from 'rxjs';

import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';

import * as Highcharts from 'highcharts';
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/export-data')(Highcharts);
const noData = require('highcharts/modules/no-data-to-display')
noData(Highcharts)

import { SiteService } from '../site.service';
import { AuthService } from '../../auth/auth.service';
import { DashboardCard, DasboardSiteLevelStatus, DashboardCurve } from '../site.model';

@Component({
  selector: "app-dashboard",
  templateUrl: "dashboard.component.html",
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, OnDestroy {
  
  private destroy = new Subject<void>();
  private subscriptionCard: Subscription;
  private subscriptionSiteLevelStatus: Subscription;
  private subscriptionCurveYield: Subscription;
  private subscriptionCurvePR: Subscription;
  timer1$ : Observable<number> = interval(60000);
  timer2$ : Observable<number> = interval(300000);

  public username: string;
  public siteId: string;
  
  public dashboardCard : DashboardCard ={
    todayYield: '0 kWh',
    totalYield: '0 kWh',
    outputPower:'0 kW',
    inputPower: '0 kW',
    peakOutputPower: '0 kW',
    peakOutputPowerTimestamp: 'NA',
    CUF: 'NA',
    PR: 'NA',
    capacity: '0 kW',
    specificYield: 0,
    revenue: '0 ₹',
    total: 0,
    normal: 0,
    alarm: 0,
    offline: 0
   
  }

  public displayedColumns: string[] = ['name', 'capacity', 'status', 'specificYield', 'todayYield','totalYield','outputPower','inputPower','timestamp'];
  public SiteLevelStatus: DasboardSiteLevelStatus[] = [];
  public dataSource = new MatTableDataSource<DasboardSiteLevelStatus>(this.SiteLevelStatus);

  public selectedPeriodYieldCurve = "1";
  public selectedPeriodPRCurve = "1";

  public dashboardYieldCurveData : DashboardCurve = {
    timestamp: [],
    dailyYield: [],
    specificYield: [],
  };

  public dashboardPRCurveData : DashboardCurve = {
    timestamp: [],
    CUF: [],
    PR: [],
  };
  
  highcharts = Highcharts;
  
  public yieldCurveOption : any = {   
      chart: {
         type: "column",
         style: {
          fontFamily: "'Open Sans', sans-serif"
      }
      },
      credits: {
        enabled: false
      },
      tooltip :{
          shared: true,
          borderColor: '#2579A2'
      },
      title: {
         text: ""
      },
      xAxis:{
         categories:this.dashboardYieldCurveData.timestamp,
         crosshair: true
      },
      yAxis: [{ // Primary yAxis
        title: {
            text: 'Daily Yield (kWh)'
          },
        }, { // Secondary yAxis
        title: {
            text: 'Specific Yield',
        },
        opposite: true
      }],
      series: [{
        name: 'Daily Yield',
        data: this.dashboardYieldCurveData.dailyYield,
        color: '#4285F4',
        tooltip: {
        valueSuffix: ' kWh'
        }
      },
      {
        name: 'Specific Yield',
        yAxis: 1,
        data: this.dashboardYieldCurveData.specificYield,
        color: '#F4B400'
      }],
      exporting: {
				buttons: {
					contextButton: {
            menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
             )
					}
				}
      },
      navigation: {
        buttonOptions: {
            verticalAlign: 'top',
            x: 0,
            y: -12
        }
      }
  };

  public yieldCurveUpdateFlag : boolean = false;

  public PRCurveOption : any = {   
    chart: {
       type: "column",
       style: {
        fontFamily: "'Open Sans', sans-serif"
    }
    },
    credits: {
      enabled: false
    },
    tooltip :{
        shared: true,
        borderColor: '#2579A2'
    },
    title: {
       text: ""
    },
    xAxis:{
       categories:this.dashboardPRCurveData.timestamp,
       crosshair: true
    },
    yAxis: [{ // Primary yAxis
      title: {
          text: 'Performance Ratio (%)'
        },
      }, { // Secondary yAxis
      title: {
          text: 'CUF (%)',
      },
      opposite: true
    }],
    series: [{
      name: 'PR',
      data: this.dashboardPRCurveData.PR,
      color: '#39AD52',
      tooltip: {
      valueSuffix: ' %'
      }
    },
    {
      name: 'CUF',
      yAxis: 1,
      data: this.dashboardPRCurveData.CUF,
      color: '#6F60B8',
      tooltip: {
        valueSuffix: ' %'
        }
    }],
    exporting: {
      buttons: {
        contextButton: {
          menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
           )
        }
      }
    },
    navigation: {
      buttonOptions: {
          verticalAlign: 'top',
          x: 0,
          y: -12
      }
    }
  };

  public PRCurveUpdateFlag : boolean = false;
  
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  constructor( private route: ActivatedRoute, private siteService: SiteService, private authService: AuthService) {}
  
  async ngOnInit() : Promise<void> {
    this.route.paramMap.pipe(
      map(ParamMap => ParamMap.get('id')),
      takeUntil(this.destroy)
    ).subscribe(siteId => this.siteService.updatePathParamState(siteId));
    this.username = this.authService.getUsername();
    this.siteId= await this.siteService.getSiteId();
    this.dashboardCards();
    this.dashboardSiteLevelStatus();
    this.dashboardYieldCurve();
    this.dashboardPRCurve();
    this.dataSource.paginator = this.paginator;
  }

  dashboardCards(){
    this.subscriptionCard = this.timer1$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getDashboardCard(this.username, this.siteId)),
      map(map => {
        return {
          todayYield: map.response.todayYield,
          totalYield: map.response.totalYield,
          outputPower: map.response.outputPower,
          inputPower: map.response.inputPower,
          peakOutputPower: map.response.peakOutputPower,
          peakOutputPowerTimestamp: map.response.peakOutputPowerTimestamp,
          CUF: map.response.CUF,
          PR: map.response.PR,
          capacity: map.response.capacity,
          specificYield: map.response.specificYield,
          revenue: map.response.revenue,
          total: map.response.total,
          normal: map.response.normal,
          alarm: map.response.alarm,
          offline: map.response.offline
        };
      })
    )
    .subscribe(res => {
      this.dashboardCard = res;
  });
  }

  dashboardSiteLevelStatus(){
    this.subscriptionSiteLevelStatus = this.timer1$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getDashboardSiteLevelStatus(this.username, this.siteId)),
      map(map => {
        return {
          "res": map.response,
        };
      })
    )
    .subscribe(res => {
      this.SiteLevelStatus = res['res'];
      this.dataSource = new MatTableDataSource<DasboardSiteLevelStatus>(this.SiteLevelStatus);
      this.dataSource.paginator = this.paginator;
    });
  }

  dashboardYieldCurve(){
    this.subscriptionCurveYield = this.timer2$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getDashboardCurve(this.username, this.siteId, this.selectedPeriodYieldCurve)),
      map(map => {
        return {
          "res": map.response,
        };
      })
    )
    .subscribe(res => {
      
      this.dashboardYieldCurveData = res['res'];

      this.yieldCurveOption.xAxis={
        categories:this.dashboardYieldCurveData.timestamp
      };

      this.yieldCurveOption.series= [{
        data: this.dashboardYieldCurveData.dailyYield
      },{
        data: this.dashboardYieldCurveData.specificYield
      }];
      this.yieldCurveUpdateFlag = true;
    });
  }

  dashboardPRCurve(){
    this.subscriptionCurvePR = this.timer2$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getDashboardCurve(this.username, this.siteId, this.selectedPeriodPRCurve)),
      map(map => {
        return {
          "res": map.response,
        };
      })
    )
    .subscribe(res => {
      
      this.dashboardPRCurveData = res['res'];

      this.PRCurveOption.xAxis={
        categories:this.dashboardPRCurveData.timestamp
      };

      this.PRCurveOption.series= [{
        data: this.dashboardPRCurveData.PR
      },{
        data: this.dashboardPRCurveData.CUF
      }];
      this.PRCurveUpdateFlag = true;
    });
  }

  changeSelectionYieldCurve() {
    this.subscriptionCurveYield.unsubscribe();
    this.dashboardYieldCurve();
  }

  changeSelectionPRCurve() {
    this.subscriptionCurvePR.unsubscribe();
    this.dashboardPRCurve();
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  ngOnDestroy() {
   this.destroy.next();
   this.destroy.complete();
   this.siteService.updatePathParamState(null);
   this.subscriptionCard.unsubscribe();
   this.subscriptionSiteLevelStatus.unsubscribe();
   this.subscriptionCurveYield.unsubscribe();
   this.subscriptionCurvePR.unsubscribe();
  }

}
