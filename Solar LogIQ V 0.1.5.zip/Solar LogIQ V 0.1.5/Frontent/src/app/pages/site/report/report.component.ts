import { Component, OnInit, OnDestroy} from "@angular/core";
import { ActivatedRoute } from '@angular/router';
import { FormControl } from '@angular/forms';
import * as fileSaver from 'file-saver';
import { BsDatepickerConfig, BsDatepickerViewMode } from 'ngx-bootstrap/datepicker';
import { SiteService } from '../site.service';


export interface siteAnalysis {
  Date: any;
  StartTime: any;
  StopTime: any;
  GenerationTime: any;
  MaxOutputPower: any;
  DailyYield: any;
  SpecificYield: any;
  TotalYield: any;
  CUF: any;
  PR: any;
  CumulativeGTI: any;
};

const ELEMENT_DATA: siteAnalysis[] = [
  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.028898', PR: '92.028898', CumulativeGTI: '0.6455'
  },

  {
    Date: '19-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '20-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '21-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },
  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },
  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },
  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },
  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },
  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },
  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },
  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },
  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },
  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },


  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },
  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },
  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

  {
    Date: '18-Sep-2020', StartTime: '06:35:16', StopTime: 'NA', GenerationTime: '05:10',
    MaxOutputPower: '81.08', DailyYield: '346', SpecificYield: '1.1', TotalYield: '282.42',
    CUF: '4.59', PR: '92.02', CumulativeGTI: '0.6455'
  },

];


@Component({
  selector: "app-report",
  templateUrl: "report.component.html",
  styleUrls: ['./report.component.scss'],
  })
export class ReportComponent implements OnInit, OnDestroy {

  displayedColumns: string[] = ['Date', 'StartTime', 'StopTime', 'GenerationTime',
  'MaxOutputPower', 'DailyYield', 'SpecificYield', 'TotalYield', 'CUF', 'PR', 'CumulativeGTI'];
  dataSource = ELEMENT_DATA;

  onViewEvent = false;
  isDaily = true;
  isDuration = false;
  isMonthly = true;
  isMonthlyActive = false;

  dailyDate = new Date();
  durationStartDate;
  durationEndDate = new Date();
  monthlyDate = new Date();
  maxDate: Date;
  minDate: any;
  

  minMode: BsDatepickerViewMode = 'month';
  bsConfig: Partial<BsDatepickerConfig> = new BsDatepickerConfig();

  selectDevice = [
    { name: 'Site Analysis' },
    { name: 'String Inverter' },
    { name: 'Weather Station' },
  ]

  constructor(private route: ActivatedRoute, private siteService: SiteService) {

  };


  ngOnInit() {
    let currentDate = new Date();
    this.durationStartDate = currentDate.setDate(currentDate.getDate() - 6);
    this.maxDate = new Date();
    this.minDate = new Date();
    this.minDate.setMonth(this.minDate.getMonth() - this.maxDate.getMonth() - 12);
    let date = new Date();
    this.minDate.setDate(this.minDate.getDate() - date.getDate() + 1);
    this.bsConfig = Object.assign({}, {
      minMode: this.minMode
    });
    this.bsConfig.dateInputFormat = 'MM-YYYY';
};

onViewAction(){
  this.onViewEvent = true;
}

downloadExcel(){
  console.log('///////****')
  this.siteService.downloadExcelSheet().subscribe(response => {
    console.log(response)
      fileSaver(response, 'Holmium report sheet');
  });
};

  onSelectDevice(event) {
    console.log(event)
  };

  onDailyDate(date: Date) {
    console.log('onDailyDate********')
    console.log(date)
    this.dailyDate = date;
  };

  onDurationStartDate(date: Date) {
    console.log('onDurationStartDate********')
    console.log(date)
    this.durationStartDate = date;
  };

  onDurationEndDate(date: any) {
    console.log('onDurationEndDate********11')
    console.log(date)
    this.durationEndDate = date;
  };

  onMonthlyDate(date: Date) {
    console.log('onMonthlyDate********')
    console.log(date)
    this.monthlyDate = date;
  };

  onDailyAction() {
    this.isDuration = false;
    this.isDaily = true;
    this.isMonthly = true;
    this.isMonthlyActive = false;
    console.log('onDailyAction is Activated!!!');
  };

  onDurationAction() {
    this.isDuration = true;
    this.isDaily = false;
    this.isMonthly = true;
    this.isMonthlyActive = false;
    console.log('onDurationAction is Activated!!!');
  };

  onMonthlyAction() {
    this.isMonthly = false;
    this.isMonthlyActive = true
    this.isDaily = false;
    this.isDuration = false;
    console.log('onMonthlyAction is Activated!!!');
  }

  ngOnDestroy() {

  }
}
