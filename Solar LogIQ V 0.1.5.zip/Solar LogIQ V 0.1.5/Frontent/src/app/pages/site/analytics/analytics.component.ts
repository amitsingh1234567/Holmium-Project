import { Component, OnInit, OnDestroy } from "@angular/core";
import { ActivatedRoute } from '@angular/router';
import { FormControl } from '@angular/forms';

import { takeUntil, map, startWith, switchMap } from 'rxjs/operators';
import { Subject, Subscription, interval, Observable } from 'rxjs';

import { MatDatepickerInputEvent, MatDatepicker } from '@angular/material/datepicker';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as _moment from 'moment';
import 'moment/locale/en-in';
import {default as _rollupMoment, Moment} from 'moment';

import * as Highcharts from 'highcharts';
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/export-data')(Highcharts);
const noData = require('highcharts/modules/no-data-to-display')
noData(Highcharts)

import { SiteService } from '../site.service';
import { AuthService } from '../../auth/auth.service';
import { AnalyticsYieldCurve, AnalyticsPerHourYieldCurve, AnalyticsOutputPowerCurve, AnalyticsPlantYieldCurve } from '../site.model';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};



interface Pokemon {
  value: string;
  viewValue: string;
}

interface PokemonGroup {
  disabled?: boolean;
  name: string;
  pokemon: Pokemon[];
}

@Component({
  selector: "app-analytics",
  templateUrl: "analytics.component.html",
  styleUrls: ['./analytics.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    {provide: MAT_DATE_LOCALE, useValue: 'en-IN'},
  ],
})
export class AnalyticsComponent implements OnInit, OnDestroy {
  
  private destroy = new Subject<void>();
  private subscriptionCurve1: Subscription;
  private subscriptionCurve2: Subscription;
  private subscriptionCurve3: Subscription;
  private subscriptionCurve4: Subscription;
  private subscriptionDevices: Subscription;
  //timer1$ : Observable<number> = interval(60000);
  timer$ : Observable<number> = interval(300000);
  timer1$ : Observable<number> = interval(900000);

  public username: string;
  public siteId: string;
  public devices = new FormControl();
  public deviceList = [];

  public datePicker1 = new FormControl(moment());
  public date ;
  public date1 = moment();
  public date2 = moment();
  public datePicker3 = new FormControl(moment());
  public datePicker4 = new FormControl(moment());

  maxDate = moment();
  minDate = moment("01/01/2019", "MM-DD-YYYY");


  public analyticsYieldCurveData : AnalyticsYieldCurve = {
    deviceName: [],
    dailyYield: [],
    specificYield: [],
  };

  highcharts = Highcharts;
  
  public yieldCurveOption : any = {   
      chart: {
         type: "column",
         style: {
          fontFamily: "'Open Sans', sans-serif"
      }
      },
      credits: {
        enabled: false
      },
      tooltip :{
          shared: true,
          borderColor: '#2579A2'
      },
      title: {
         text: ""
      },
      xAxis:{
         categories:this.analyticsYieldCurveData.deviceName,
         crosshair: true
      },
      yAxis: [{ 
        title: {
            text: 'Daily Yield (kWh)'
          }
      }],
      series: [{
        name: 'Daily Yield',
        data: this.analyticsYieldCurveData.dailyYield,
        color: '#4285F4',
        tooltip: {
        valueSuffix: ' kWh'
        }
      }],
      exporting: {
				buttons: {
					contextButton: {
            menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
             )
					}
				}
      },
      navigation: {
        buttonOptions: {
            verticalAlign: 'top',
            x: 0,
            y: -12
        }
      }
  };

  public specficYieldCurveOption : any = {   
    chart: {
       type: "column",
       style: {
        fontFamily: "'Open Sans', sans-serif"
    }
    },
    credits: {
      enabled: false
    },
    tooltip :{
        shared: true,
        borderColor: '#2579A2'
    },
    title: {
       text: ""
    },
    xAxis:{
       categories:this.analyticsYieldCurveData.deviceName,
       crosshair: true
    },
    yAxis: [{ 
      title: {
          text: 'Specific Yield',
      }
    }],
    series: [{
      name: 'Specific Yield',
      data: this.analyticsYieldCurveData.specificYield,
      color: '#F4B400'
    }],
    exporting: {
      buttons: {
        contextButton: {
          menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
           )
        }
      }
    },
    navigation: {
      buttonOptions: {
          verticalAlign: 'top',
          x: 0,
          y: -12
      }
    }
  };

  public yield_SpecficYieldCurveUpdateFlag : boolean = false;

  public selectedPeriodSiteYieldCurve = "1";

  public analyticsPlantYieldCurveData : AnalyticsPlantYieldCurve = {
    timestamp: [],
    siteYield: []
  };

  public plantYieldCurveOption : any = {   
    chart: {
       type: "column",
       style: {
        fontFamily: "'Open Sans', sans-serif"
    }
    },
    credits: {
      enabled: false
    },
    tooltip :{
        shared: true,
        borderColor: '#2579A2'
    },
    title: {
       text: ""
    },
    xAxis:{
       categories:this.analyticsPlantYieldCurveData.timestamp,
       crosshair: true
    },
    yAxis: [{ 
      title: {
          text: 'Site Yield (kWh)'
        }
    }],
    series: [{
      name: 'Site Yield',
      data: this.analyticsPlantYieldCurveData.siteYield,
      color: '#6F60B8',
      tooltip: {
      valueSuffix: ' kWh'
      }
    }],
    exporting: {
      buttons: {
        contextButton: {
          menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
           )
        }
      }
    },
    navigation: {
      buttonOptions: {
          verticalAlign: 'top',
          x: 0,
          y: -12
      }
    }
  };

  public plantYieldCurveUpdateFlag : boolean = false;

  public analyticsPerHourYieldCurveData : AnalyticsPerHourYieldCurve = {
    timestamp: [],
    perHourYield: []
  };

  public perHourYieldCurveOption : any = {   
      chart: {
         type: "column",
         style: {
          fontFamily: "'Open Sans', sans-serif"
      }
      },
      credits: {
        enabled: false
      },
      tooltip :{
          shared: true,
          borderColor: '#2579A2'
      },
      title: {
         text: ""
      },
      xAxis:{
         categories:this.analyticsPerHourYieldCurveData.timestamp,
         crosshair: true
      },
      yAxis: [{ 
        title: {
            text: 'Per Hour Yield (kWh)'
          }
      }],
      series: [{
        name: 'Per Hour Yield',
        data: this.analyticsPerHourYieldCurveData.perHourYield,
        color: '#08A0A3',
        tooltip: {
        valueSuffix: ' kWh'
        }
      }],
      exporting: {
				buttons: {
					contextButton: {
            menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
             )
					}
				}
      },
      navigation: {
        buttonOptions: {
            verticalAlign: 'top',
            x: 0,
            y: -12
        }
      }
  };

  public perHourYieldCurveUpdateFlag : boolean = false;

  public analyticsOutputPowerCurveData : AnalyticsOutputPowerCurve = {
    timestamp: []
  };

  public outputPowerCurveOption : any = {   
    chart: {
       type: "spline",
       style: {
        fontFamily: "'Open Sans', sans-serif"
    }
    },
    credits: {
      enabled: false
    },
    tooltip :{
        shared: true,
        borderColor: '#2579A2'
    },
    title: {
       text: ""
    },
    xAxis:{
       categories:this.analyticsOutputPowerCurveData.timestamp
    },
    yAxis: [{ // Primary yAxis
      title: {
          text: 'Output Power (kW)'
        },
      },{ // Secondary yAxis
        title: {
            text: 'Irradiance (w/m2)'
          },
        opposite: true
      }],
    series: [],
    exporting: {
      buttons: {
        contextButton: {
          menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
           )
        }
      }
    },
    navigation: {
      buttonOptions: {
          verticalAlign: 'top',
          x: +5,
          y: -12
      }
    },
    plotOptions:{
      spline: {
        marker: {
            radius: 3,
            states: { hover: { radius: 6 } }
        },
      }
    },
  };
 
  public outputPowerUpdateFlag : boolean = false;
  public outputPowerOneToOneFlag  : boolean = false;

  //date = new FormControl(new Date());
  serializedDate = new FormControl((new Date()).toISOString());
  
  bsValue = new Date();
  bsRangeValue: Date[];
  
  constructor( private route: ActivatedRoute, private siteService: SiteService, private authService: AuthService) { }

  async ngOnInit() : Promise<void> {
    this.route.paramMap.pipe(
      map(ParamMap => ParamMap.get('id')),
      takeUntil(this.destroy)
    ).subscribe(siteId => this.siteService.updatePathParamState(siteId));
    this.username = this.authService.getUsername();
    this.siteId= await this.siteService.getSiteId();
    this.subscriptionDevices = this.siteService.getSiteDevices(this.username, this.siteId)
    .pipe(
      map(map => {
        return {
          devices:map.response.stringInverter
        };
      })
    )
    .subscribe(res => {
      res.devices.forEach(element => {
        this.deviceList.push({name:element.building+' '+element.name, id:element.id})
      });
      this.devices.setValue ([this.deviceList[0].id.toString()]);
      this.analyticsOutputPowerCurve();
   });
    this.analyticsYieldCurve();
    this.analyticsPlantYieldCurve();
    this.analyticsPerHourYieldCurve();
  }

  analyticsYieldCurve(){
    this.subscriptionCurve1 = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getAnalyticsCurve1(this.username, this.siteId, this.datePicker1.value)),
      map(map => {
        return {
          "res": map.response,
        };
      })
    )
    .subscribe(res => {
      this.analyticsYieldCurveData = res['res'];

      this.yieldCurveOption.xAxis={
        categories:this.analyticsYieldCurveData.deviceName
      };

      this.yieldCurveOption.series= [{
        data: this.analyticsYieldCurveData.dailyYield
      }];

      this.specficYieldCurveOption.xAxis={
        categories:this.analyticsYieldCurveData.deviceName
      };

      this.specficYieldCurveOption.series= [{
        data: this.analyticsYieldCurveData.specificYield
      }];

      this.yield_SpecficYieldCurveUpdateFlag = true;
      
    });
  }

  analyticsPlantYieldCurve()
  {
    if(this.selectedPeriodSiteYieldCurve == '1')
      this.date = this.date1.valueOf();
    else if(this.selectedPeriodSiteYieldCurve == '2')
      this.date = this.date2.valueOf();

    this.subscriptionCurve2 = this.timer1$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getAnalyticsCurve2(this.username, this.siteId, this.selectedPeriodSiteYieldCurve, this.date)),
      map(map => {
        return {
          "res": map.response,
        };
      })
    )
    .subscribe(res => {
      this.analyticsPlantYieldCurveData = res['res'];

      this.plantYieldCurveOption.xAxis={
        categories:this.analyticsPlantYieldCurveData.timestamp
      };

      this.plantYieldCurveOption.series= [{
        data: this.analyticsPlantYieldCurveData.siteYield
      }];

      this.plantYieldCurveUpdateFlag = true;
      
    });
  }

  analyticsOutputPowerCurve(){
    this.subscriptionCurve3 = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getAnalyticsCurve3(this.username, this.siteId, this.datePicker3.value, this.devices.value)),
      map(map => {
        return {
          "res": map.response,
        };
      })
    )
    .subscribe(res => {
      
      this.analyticsOutputPowerCurveData = res['res'];
      this.outputPowerCurveOption.series=[];
      
      for (let entries of Object.entries(this.analyticsOutputPowerCurveData)) {
        
        if(entries[0] == 'timestamp')
        {
          this.outputPowerCurveOption.xAxis={
            categories:this.analyticsOutputPowerCurveData.timestamp
          };
        }
        else if(entries[0].includes("GTI"))
        {
          this.outputPowerCurveOption.series.push({
            name: entries[0],
            data: entries[1],
            yAxis:1,
            tooltip: {
            valueSuffix: ' w/m2'
            }
          });
        }
        else if ((entries[0].includes("Inverter")))
        {
          this.outputPowerCurveOption.series.push({
            name: entries[0],
            data: entries[1],
            tooltip: {
            valueSuffix: ' A'
            }
          });
        }
      }

      this.outputPowerUpdateFlag = true;
      this.outputPowerOneToOneFlag = true;
      
    });
  }

  analyticsPerHourYieldCurve(){
    this.subscriptionCurve4 = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getAnalyticsCurve4(this.username, this.siteId, this.datePicker4.value)),
      map(map => {
        return {
          "res": map.response,
        };
      })
    )
    .subscribe(res => {

      this.analyticsPerHourYieldCurveData = res['res'];

      this.perHourYieldCurveOption.xAxis={
        categories:this.analyticsPerHourYieldCurveData.timestamp
      };

      this.perHourYieldCurveOption.series= [{
        data: this.analyticsPerHourYieldCurveData.perHourYield
      }];

      this.perHourYieldCurveUpdateFlag = true;
      
    });
  }

  changeDatePicker1(event: MatDatepickerInputEvent<Date>)
  {
    this.datePicker1.setValue(event.value)
    this.subscriptionCurve1.unsubscribe();
    this.analyticsYieldCurve();
  
  }

  changeDatePicker2_1(event) {
    this.date1 = event;
    this.subscriptionCurve2.unsubscribe();
    this.analyticsPlantYieldCurve();
  }

  changeDatePicker2_2(event) {  
    this.date2 = event;
    this.subscriptionCurve2.unsubscribe();
    this.analyticsPlantYieldCurve();
  }

  changeDatePicker3(event: MatDatepickerInputEvent<Date>)
  {
    this.datePicker3.setValue(event.value)
    this.subscriptionCurve3.unsubscribe();
    this.analyticsOutputPowerCurve();
  }

  changeDatePicker4(event: MatDatepickerInputEvent<Date>)
  {
    this.datePicker4.setValue(event.value)
    this.subscriptionCurve4.unsubscribe();
    this.analyticsPerHourYieldCurve();
  }

  changePeriod()
  {
    this.subscriptionCurve2.unsubscribe();
    this.analyticsPlantYieldCurve();
  }

  changeInverter()
  {
    this.subscriptionCurve3.unsubscribe();
    this.analyticsOutputPowerCurve();
  }

  ngOnDestroy() {
    this.destroy.next();
    this.destroy.complete();
    this.siteService.updatePathParamState(null);
    this.subscriptionCurve1.unsubscribe();
    this.subscriptionCurve2.unsubscribe();
    this.subscriptionCurve3.unsubscribe();
    this.subscriptionCurve4.unsubscribe();
   }
}

