  export interface Response {
    status: boolean, 
    message: string, 
    response: any
  }

  export interface Device {
    "D-LOG"?: boolean,
    "String Inverter"?: boolean,
    "Centralized Inverter"?: boolean,
    "Weather Station"?: boolean,
    "Meter"?: boolean,
    "PV-DG Sync"?: boolean,
    "Zero Export"?: boolean
  }

  export interface DashboardCard {
    timestamp?: string,
    todayYield?: string,
    totalYield?: string,
    outputPower?: string,
    inputPower?: string,
    peakOutputPower?: string,
    peakOutputPowerTimestamp?: string,
    CUF?: String,
    PR?: String,
    capacity?: string,
    specificYield?: Number,
    revenue?: String,
    total?: Number,
    normal?: Number,
    alarm?: Number,
    offline?: Number
  }

  export interface DasboardSiteLevelStatus {
    name?: string,
    capacity?: string,
    status?: string,
    statusClass: string,
    SpecificYield: string,
    todayYield?: string,
    totalYield?: string,
    outputPower?: string,
    inputPower?: string,
    timestamp?: String
  }

  export interface DashboardCurve {
    timestamp?: Array<any>,
    dailyYield?: Array<any>,
    specificYield?: Array<any>,
    CUF?: Array<any>,
    PR?: Array<any>
  }

  export interface AnalyticsYieldCurve {
    deviceName?: Array<any>,
    dailyYield?: Array<any>,
    specificYield?: Array<any>,
  }

  export interface AnalyticsPlantYieldCurve {
    timestamp?: Array<any>,
    siteYield?: Array<any>
  }

  export interface AnalyticsOutputPowerCurve {
    timestamp ?: Array<any>,
    [key: string]:  Array<any>
  }

  export interface AnalyticsPerHourYieldCurve {
    timestamp?: Array<any>,
    perHourYield?: Array<any>,
  }

  export interface StringInverterCard {
    timestamp: string,
    status: string,
    todayYield: string,
    totalYield: string,
    outputPower: string,
    inputPower: string,
    peakOutputPower: string,
    peakOutputPowerTimestamp: string,
    specificYield: number,
    specificPower: number,
    temperature: string,
    efficiency: string,
    capacity: string
  }

  export interface StringInverterCurve{
    time : Array<any>,
    dailyYield : Array<any>,
    totalYield : Array<any>,
    outputCurrent ?: Array<any>,
    inputCurrent ?: Array<any>,
    outputPower ?: Array<any>,
    inputPower ?: Array<any>,
    temperature ?: Array<any>,
    efficiency ?: Array<any>,
    MPPT1?: Array<any>,
    MPPT2?: Array<any>,
    MPPT3?: Array<any>,
    MPPT4?: Array<any>,
    MPPT5?: Array<any>,
    MPPT6?: Array<any>,
    MPPT7?: Array<any>,
    MPPT8?: Array<any>,
    MPPT9?: Array<any>,
    MPPT10?: Array<any>,
    MPPT11?: Array<any>,
    MPPT12?: Array<any>,
    MPPT13?: Array<any>,
    MPPT14?: Array<any>,
    MPPT15?: Array<any>,
    String1?: Array<any>,
    String2?: Array<any>,
    String3?: Array<any>,
    String4?: Array<any>,
    String5?: Array<any>,
    String6?: Array<any>,
    String7?: Array<any>,
    String8?: Array<any>,
    String9?: Array<any>,
    String10?: Array<any>,
    String11?: Array<any>,
    String12?: Array<any>,
    String13?: Array<any>,
    String14?: Array<any>,
    String15?: Array<any>,
    String16?: Array<any>,
    String17?: Array<any>,
    String18?: Array<any>,
    String19?: Array<any>,
    String20?: Array<any>,
    String21?: Array<any>,
    String22?: Array<any>,
    String23?: Array<any>,
    String24?: Array<any>,
    String25?: Array<any>,
    String26?: Array<any>,
    String27?: Array<any>,
    String28?: Array<any>,
    String29?: Array<any>,
    String30?: Array<any>
   }

   export interface WeatherStationCard {
    timestamp: string,
    status: string,
    irradiance: string,
    cumulativeIrradiance: string,
    ambientTemperature: string,
    moduleTemperature: string,
    windSpeed: string,
    windDirection: string,
    relativeHumidity: string,
    rainGauge: string
  }

  export interface WeatherStationIrradianceCurve {
    time: Array<any>,
    GHI?: Array<any>,
    GTI1?: Array<any>,
    GTI2?: Array<any>,
    GTI3?: Array<any>,
    GTI4?: Array<any>,
    GTI5?: Array<any>
  }

  export interface WeatherStationTemperatureCurve {
    time: Array<any>,
    ambientTemperature?: Array<any>,
    moduleTemperature1?: Array<any>,
    moduleTemperature2?: Array<any>,
    moduleTemperature3?: Array<any>,
    moduleTemperature4?: Array<any>,
    moduleTemperature5?: Array<any>
  }

  export interface WeatherStationWindCurve {
    time: Array<any>,
    windSpeedDirection?: Array<any>,
    windSpeed?: Array<any>,
    windDirection?: Array<any>
  }

  export interface WeatherStationRainCurve {
    time: Array<any>,
    relativeHumidity?: Array<any>,
    rainfall?: Array<any>
  }

  export interface AlarmDetail {
    'unit'?: String, 
    'state'?: String, 
    'operatingStatus'?: String,  
    'fault'?: String, 
    'from'?: String, 
    'to'?: String, 
    'duration'?: String
  }

  export interface InformationCard {
    siteName ?: String,
    capacity ?: String,
    location ?: String,
    coordinates?: String,
    commissioningDate?: String,
    portalLicenseDate?: String,
    owner?: String,
    unitPrice?: String,
    D_LOG?: String,
    inverter?: String,
    weatherStation?: String,
    meter?: String,
    PV_DGSync?: String,
    zeroExport?: String,
    PVModuleQuantity?: String,
    PVModuleWattage?: String
  }

  export interface D_LOGProfile {
    name?: number;
    modelNo?: string;
    serialNo?: string;
    building?:string;
    deviceConnected?: number;
  }

  export interface StringInverterProfile {
    inverter_no?: number;
    capacity?: string;
    make?: string;
    model_no?:string;
    serial_no?: string;
    building?:string;
    string?:string;
  }

  export interface CentralizedInverterProfile {
    inverter_no?: number;
    capacity?: string;
    make?: string;
    model_no?:string;
    serial_no?: string;
    building?:string;
    units?:string;
  }

  export interface WeatherStationProfile {
    weatherstation_no?: number;
    make?: string;
    model_no?:string;
    serial_no?: string;
    building?:string;
    sensors?:string;
  }
  export interface MeterProfile {
    meter_no?: number;
    make?: string;
    model_no?:string;
    serial_no?: string;
    building?:string;
  }
  export interface DieselGeneratorProfile {
    dg_no?: number;
    capacity?: string;
    make?: string;
    model_no?:string;
    building?:string;
  }