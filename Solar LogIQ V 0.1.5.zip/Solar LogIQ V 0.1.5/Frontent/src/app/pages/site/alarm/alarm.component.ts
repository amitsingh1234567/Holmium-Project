import { Component, OnInit, OnDestroy, ViewChild } from "@angular/core";
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { takeUntil, map, startWith, switchMap } from 'rxjs/operators';
import { Subject, Subscription, Observable, interval } from 'rxjs';

import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as _moment from 'moment';
import 'moment/locale/en-in';
import {default as _rollupMoment} from 'moment';

import { SiteService } from '../site.service';
import { AuthService } from '../../auth/auth.service';
import { Device, AlarmDetail } from '../site.model';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: "app-alarm",
  templateUrl: "alarm.component.html",
  styleUrls: ['./alarm.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    {provide: MAT_DATE_LOCALE, useValue: 'en-IN'},
  ],
})
export class AlarmComponent implements OnInit, OnDestroy {
  
  private destroy = new Subject<void>();
  private subscriptionDevices: Subscription;
  private subscriptionAlarm: Subscription;
  timer$ : Observable<number> = interval(60000);
  
  public username: string;
  public siteId: string;
  public devices : Device = {};

  public selectedDevice : string;
  public selectedState = 'Open';
  public datePicker = new FormControl(moment());
  maxDate = moment();
  minDate = moment("01/01/2019", "MM-DD-YYYY");

  public displayedColumns: string[] = ['unit', 'state', 'operatingStatus', 'fault','from','to','duration'];
  public alarmDetail: AlarmDetail[] = [];
  public dataSource = new MatTableDataSource<AlarmDetail>(this.alarmDetail);

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  
  constructor( private route: ActivatedRoute, private siteService: SiteService, private authService: AuthService) {}

  async ngOnInit() : Promise<void>  {
    this.route.paramMap.pipe(
      map(ParamMap => ParamMap.get('id')),
      takeUntil(this.destroy)
    ).subscribe(siteId => this.siteService.updatePathParamState(siteId));

    this.username = this.authService.getUsername();
    this.siteId= await this.siteService.getSiteId();
    this.subscriptionDevices = this.siteService.getSiteNavigation(this.username, this.siteId)
    .pipe(
      map(map => {
        return {
          "D-LOG": map.response.D_LOG,
          "String Inverter": map.response.stringInverter,
          "Centralized Inverter": map.response.centralizedInverter,
          "Weather Station": map.response.weatherStation,
          "Meter": map.response.meter,
          "PV-DG Sync": map.response.PV_DGSync,
          "Zero Export": map.response.zeroExport
        };
      })
    )
    .subscribe(res => {
      this.devices = res;

      if(this.devices["String Inverter"] == true)
        this.selectedDevice = "String Inverter";
      else if(this.devices["Centralized Inverter"] == true)
        this.selectedDevice = "Centralized Inverter";
     
      this.AlarmData(); 
   });
  }

  AlarmData()
  {
    this.subscriptionAlarm = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getAlarmDetail(this.username, this.siteId, this.selectedDevice, this.selectedState, this.datePicker.value)),
      map(map => {
        return {
          "res": map.response.alarm,
        };
      })
    )
    .subscribe(res => {
      this.alarmDetail = res['res'];
      this.dataSource = new MatTableDataSource<AlarmDetail>(this.alarmDetail);
      this.dataSource.paginator = this.paginator;
    });
  }

  changeDevice(){
    this.subscriptionAlarm.unsubscribe();
    this.AlarmData();
  }
  
  changeState(){
    this.subscriptionAlarm.unsubscribe();
    this.AlarmData();
  }
  
  changeDate(event: MatDatepickerInputEvent<Date>){
    this.datePicker.setValue(event.value)
    this.subscriptionAlarm.unsubscribe();
    this.AlarmData();
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  ngOnDestroy() {
    this.destroy.next();
    this.destroy.complete();
    this.siteService.updatePathParamState(null);
    this.subscriptionDevices.unsubscribe();
    this.subscriptionAlarm.unsubscribe();
   }
}
