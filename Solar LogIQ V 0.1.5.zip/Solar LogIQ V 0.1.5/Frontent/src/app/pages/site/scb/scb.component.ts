import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BsDaterangepickerDirective, BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { Router } from '@angular/router';
import * as Highcharts from 'highcharts';
// import * as highchartsHeatmap from 'highcharts/modules/heatmap';

import Heatmap from 'highcharts/modules/heatmap.js';
import HC_exporting from 'highcharts/modules/exporting';
declare var require: any;
let Boost = require('highcharts/modules/boost');
let noData = require('highcharts/modules/no-data-to-display');
let More = require('highcharts/highcharts-more');
// let heatMap = require('highcharts/modules/heatmap')
Heatmap(Highcharts);
Boost(Highcharts);
noData(Highcharts);
More(Highcharts);
noData(Highcharts);



@Component({
  selector: 'app-scb',
  templateUrl: './scb.component.html',
  styleUrls: ['./scb.component.scss']
})



export class ScbComponent implements OnInit {
  chartOptions = {};
  highchart = Highcharts;
  scbDate = new Date()
  selected: number = 1;

  scbDropdownDate: any[] = [
    { id: 1, name: 'SCB-1' },
    { id: 2, name: 'SCB-2' },
    { id: 3, name: 'SCB-3' },
    { id: 4, name: 'SCB-4' },
    { id: 5, name: 'SCB-5' },
    { id: 6, name: 'SCB-6' }
  ];

  data = [
    ["2017-01-01", 0, 2.7],
    ["2017-01-01", 1, 2.5],
    ["2017-01-01", 2, 1.8],
    ["2017-01-01", 3, 1.5],
    ["2017-01-01", 4, 1.8],
    ["2017-01-01", 5, 1.7],
    ["2017-01-01", 6, 1.7],
    ["2017-01-01", 7, 1.7],
    ["2017-01-01", 8, 1.7],
    ["2017-01-01", 9, 1.9],
    ["2017-01-01", 10, 2.0],
    ["2017-01-01", 11, 3.4]
  ]

  constructor(private router: Router) {};

  ngOnInit(): void {
    console.log('Scb............');
    this.largeHeatMap();
  };

  onSelect(id: number){
    console.log(id)
  }

  // onDatePick(event){
  //   console.log(event)
  // }

  onDateValueChange(value: Date): void {        
  console.log(value);
  }

  largeHeatMap() {
    // legend: {
    //   useHTML: true,
    //   itemStyle: {
    //     lineHeight: "23px"
    //   },
    //   squareSymbol: false,
    //   symbolHeight: 3,
    //   symbolWidth: 20
    // },
    this.chartOptions = {
      legend: {
        itemStyle: {
            color: '#FFFFFF',
            fontWeight: 'bold'
        }
    },
      chart: {
        type: 'heatmap',
        backgroundColor: '#343a40',
      },
      // itemStyle:{'font-size':'50px'},
      credits: {
        enabled: false
      },
      // legend: {
      //   // enabled: true,
      //   // useHTML: true,
      //   // color: '#FFFFFF',
      //       // backgroundColor: '#FCFFC5',
      //       itemStyle: {
      //         color: '#FFFFFF'
      //      },
        
      // },
      boost: {
        useGPUTranslations: true
      },
      
      title: {
        text: null,
        // align: 'left',
        // x: 60,
      },

      subtitle: {
        text: null,
        // align: 'left',
        // x: 60,
      },

      xAxis: {
        type: 'datetime',
        categories: [
          "Jan",
          "Feb",
          "Mar",
          "Apr",
          "May",
          "Jun",
          "Jul",
          "Aug",
          "Sep",
          "Oct",
          "Nov",
          "Dec"
        ],
        labels: {
          style: {
            color: '#FFFFFF',
          
          }
        },
        // min: Date.UTC(2017, 0, 1),
        // max: Date.UTC(2017, 11, 31, 23, 59, 59),
        // labels: {
        //   align: 'left',
        //   x: 2,
        //   y: 15,
        //   format: '{value:%B}' // long month
        // },

        
        showLastLabel: false,
        tickLength: 16
      },

      yAxis: {
        title: {
          text: null
        },
        labels: {
          format: '{value}:00',
          style: {
            color: '#FFFFFF'
          }
        },
        minPadding: 0,
        maxPadding: 0,
        startOnTick: false,
        endOnTick: false,
        tickPositions: [0, 6, 12, 18, 24],
        tickWidth: 1,
        min: 0,
        max: 23,
        reversed: true
      },

      colorAxis: {
        stops: [
          [0, '#3060cf'],
          [0.5, '#fffbbc'],
          [0.9, '#c4463a'],
          [1, '#c4463a']
        ],
        min: -15,
        max: 25,
        startOnTick: false,
        endOnTick: false,
        labels: {
          format: '{value}℃',
        }
      },

      series: [{
        boostThreshold: 100,
        borderWidth: 0,
        nullColor: '#EFEFEF',
        colsize: 24 * 36e5, // one day
        data: [[0,  2.7],
        [1, 2.5],
        [2, 1.8],
        [3, 1.5],
        [4, 1.8],
        [5, 1.7],
        [6, 23],
        [7, 1.7],
        [8, 1.7],
        [9, 1.9],
        [10, 2.0],
        [11, -10]
        ],
        tooltip: {
          headerFormat: 'Temperature<br/>',
          pointFormat: '{point.x:%e %b, %Y} {point.y}:00: <b>{point.value} ℃</b>'
        },
        turboThreshold: Number.MAX_VALUE // #3404, remove after 4.0.5 release
      }]

    }
    HC_exporting(Highcharts);
  }


}
