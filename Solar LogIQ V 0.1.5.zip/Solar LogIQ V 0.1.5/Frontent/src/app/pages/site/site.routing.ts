import { Routes } from "@angular/router";

import { DashboardComponent } from "./dashboard/dashboard.component";
import { AnalyticsComponent } from "./analytics/analytics.component";
import { StringInverterComponent } from "./stringinverter/stringinverter.component";
import { WmsComponent } from "./wms/wms.component";
import { MeterComponent } from "./meter/meter.component";
import { PV_DGSyncComponent } from "./pv-dgsync/pv-dgsync.component";
import { ZeroExportComponent } from "./zeroexport/zeroexport.component";
import { AlarmComponent } from "./alarm/alarm.component";
import { ReportComponent } from "./report/report.component";
import { CalendarComponent } from "./calendar/calendar.component";
import { InformationComponent } from "./information/information.component";
import { HomeComponent } from './home/home.component';
import { InverterComponent } from './inverter/inverter.component';
import { ScbComponent } from './scb/scb.component';

export const SiteRoutes: Routes = [
  { 
    path: "dashboard",
    component: DashboardComponent
  },
  {
    path: "analytics",
    component: AnalyticsComponent,
  },
  {
    path: "stringinverter",
    component: StringInverterComponent,
  },
  {
    path: "wms",
    component: WmsComponent,
  },
  {
    path: "meter",
    component: MeterComponent,
  },
  {
    path: "pv-dgsync",
    component: PV_DGSyncComponent,
  },
  {
    path: "zeroexport",
    component: ZeroExportComponent,
  },
  {
    path: "alarm",
    component:  AlarmComponent,
  },
  {
    path: "report",
    component: ReportComponent,
  },
  {
    path: "calendar",
    component: CalendarComponent,
  },
  {
    path: "information",
    component: InformationComponent,
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path:'inverter',
    component: InverterComponent
  },
  {
    path: 'scb',
    component: ScbComponent
  },
  {
    path: "**",
    redirectTo: "/outline/overview",
  } 
];
