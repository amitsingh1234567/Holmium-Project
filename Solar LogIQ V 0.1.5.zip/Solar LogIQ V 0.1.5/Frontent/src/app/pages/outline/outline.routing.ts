import { Routes } from "@angular/router";

import { OverviewComponent } from "./overview/overview.component";
import { ProfileComponent } from "./profile/profile.component";
//import { AuthGuard } from '../../auth-strategy/auth.guard';

export const OutlineRoutes: Routes = [
  {
    path: "overview",
    component: OverviewComponent,
    //canActivate: [AuthGuard]
     
  },
  {
    path: "profile",
    component: ProfileComponent,
    //canActivate: [AuthGuard]
  },
  {
    path: "**",
    redirectTo: "/outline/overview",
  } 
];
