import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs'

import { AuthService } from './auth.service';
//import { MyserviceService } from '../myservice.service';


@Injectable()
export class AuthGuard implements CanActivate {
    
    constructor(public router: Router, private authService: AuthService) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
       const isAuth = this.authService.getIsAuthenticated();
        //this._myService.plantId(route);
        if (!isAuth) {
            this.router.navigate(['/']);
        }
        return true; 
    }
   
}
