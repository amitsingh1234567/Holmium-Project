import { Injectable } from "@angular/core"
import { HttpClient } from '@angular/common/http';
import { Router } from "@angular/router";
import { Subject } from 'rxjs';


import { AuthData } from './authData.model';

@Injectable({ providedIn: "root"})

export class AuthService{

    private isAuthenticated = false;
    private username: string;
    private token:string;
    private tokenTimer: NodeJS.Timer;
    private authStatusListener = new Subject<boolean>();

    constructor(public router: Router, private http:HttpClient){}

    getUsername() {
        return this.username;
    }

    getToken(){
        return this.token;
    }

    getIsAuthenticated(){
        return this.isAuthenticated;
    }

    getAuthStatusListener(){
        return this.authStatusListener.asObservable();
    }

    login(username: string, password: string){
        const authData: AuthData = { username: username, password:password}
        this.http.post<{success: boolean, message: string, token:string, username: string, expiresIn:number}>("http://www.holmiumtechnologies.com/beta/rms/api/user/login", authData)
            .subscribe(response=>{
                console.log(response)
                const token = response.token;
                this.token = token;
                if(token){
                    const expiresIn = response.expiresIn;
                    this.setAuthTimer(expiresIn);
                    const now = new Date();
                    const expirationDate = new Date(now.getTime() + expiresIn * 1000);
                    this.username = response.username;
                    console.log(this.username);
                    this.isAuthenticated = true;
                    this.authStatusListener.next(true);
                    this.saveAuthData(token, expirationDate, this.username);
                    this.router.navigate(['/site/101/home']); 
                    //this.router.navigate(['/outline/overview']); 
                }
                
            }, error => {
                //console.log(error);
                this.authStatusListener.next(false);
            });
    }

    autoAuthUser(){
        const authInformation = this.getAuthData();
        if(!authInformation){
            return;
        }
        const now = new Date();
        const expiresIn = authInformation.expirationDate.getTime() - now.getTime();
        console.log(authInformation, expiresIn);
        if (expiresIn > 0) {
            this.token = authInformation.token;
            this.isAuthenticated = true;
            this.username = authInformation.username;
            this.setAuthTimer(expiresIn/1000);
            this.authStatusListener.next(true);
          }
    }

    logout(){
        this.token = null;
        this.isAuthenticated=false;
        this.authStatusListener.next(false);
        clearTimeout(this.tokenTimer);
        this.username = null;
        this.clearAuthData();
        this.router.navigate(['/']); 
    }

    private setAuthTimer(duration: number) {
        console.log('Setting timer: ' + duration)
        this.tokenTimer = setTimeout(() => {
          this.logout();
        }, duration * 1000);
    }

    private saveAuthData(token: string, expirationDate: Date, username: string){
        localStorage.setItem("token", token);
        localStorage.setItem("expirationDate", expirationDate.toISOString());
        localStorage.setItem("username", username);
    }

    private clearAuthData(){
        localStorage.removeItem("token");
        localStorage.removeItem("expirationDate");
        localStorage.removeItem("username");
    }

    private getAuthData(){
        const token = localStorage.getItem("token");
        const expirationDate = localStorage.getItem("expirationDate");
        const username = localStorage.getItem("username");
        if (!token || !expirationDate) {
            return;
        }
            return {
            token: token,
            expirationDate: new Date(expirationDate),
            username: username
        }
    }
}