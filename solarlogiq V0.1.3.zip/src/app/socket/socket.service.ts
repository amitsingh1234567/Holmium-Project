import { Injectable } from '@angular/core';
import * as io from 'socket.io-client';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class SocketService {
  public socket:any;
  readonly uri = 'http://localhost:3000/';

  constructor() { }

  listner(){
    this.socket = io(this.uri);
    this.socket.on('hello', data => {
      console.log(data);
    });

    this.socket.emit('getData', {msg: 'From Client...22'});



  }
 
  

}
