import { Component, OnInit, HostListener } from "@angular/core";

@Component({
  selector: "app-outline-layout",
  templateUrl: "./outline-layout.component.html",
  styleUrls: ["./outline-layout.component.scss"]
})
export class OutlineLayoutComponent implements OnInit {

  constructor() {}
 
  ngOnInit() {}
}
