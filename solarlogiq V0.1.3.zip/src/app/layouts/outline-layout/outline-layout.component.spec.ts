import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { OutlineLayoutComponent } from "./outline-layout.component";

describe("OutlineLayoutComponent", () => {
  let component: OutlineLayoutComponent;
  let fixture: ComponentFixture<OutlineLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [OutlineLayoutComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OutlineLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
