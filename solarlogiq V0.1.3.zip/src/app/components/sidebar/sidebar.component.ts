import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { Subscription } from 'rxjs';
import { map } from 'rxjs/operators';

import { AuthService } from '../../pages/auth/auth.service';
import { SiteService } from '../../pages/site/site.service';
import { ComponentsService } from '../components.service';

var misc: any = {
  sidebar_mini_active: true
};

export interface RouteInfo {
  path: string;
  title: string;
  type: string;
  icontype: string;
  collapse?: string;
  isCollapsed?: boolean;
  isCollapsing?: any;
  children?: ChildrenItems[];
}

export interface ChildrenItems {
  path: string;
  title: string;
  type?: string;
  collapse?: string;
  flag?: boolean;
  isCollapsed?: boolean;
}

@Component({
  selector: "app-sidebar",
  templateUrl: "./sidebar.component.html",
  styleUrls: ["./sidebar.component.scss"]
})

export class SidebarComponent implements OnInit {
  
  public menuItems: any[];
  public isCollapsed = true;
  public siteId: string;
  public username: string;
  private Subscription:Subscription;
  
  //Menu Items
  public ROUTES: RouteInfo[] = [
    {
      path: "/outline/overview",
      title: "Overview",
      type: "link",
      icontype: "ni-shop text-primary"
    },
    {
      path: "/site/:siteId",
      title: "Site Name",
      type: "sub",
      icontype: "ni-bullet-list-67 text-red",
      isCollapsed: true,
      children: [
        { path: "dashboard", title: "Dashboard", type: "link", flag: true },
        { path: "analytics", title: "Analytics", type: "link", flag: true },
        { path: "inverter", title: "Inverter", type: "link", flag: true },
        { path: "weatherstation", title: "Weather Station", type: "link", flag: false },
        { path: "meter", title: "Meter", type: "link", flag: false },
        { path: "pv-dgsync", title: "PV-DG Sync", type: "link", flag: false },
        { path: "zeroexport", title: "Zero Export", type: "link", flag: false },
        { path: "alarm", title: "Alarm", type: "link", flag: true },
        { path: "report", title: "Report", type: "link", flag: true },
        { path: "calendar", title: "Calendar", type: "link", flag: false },
        { path: "information", title: "Information", type: "link", flag: true }
      ]
    }
  ];

  constructor(private router: Router, public authService:AuthService, private siteService: SiteService, public componentsService: ComponentsService) { }

  async ngOnInit() : Promise<void>{

    this.username = this.authService.getUsername();
    this.siteId = await this.siteService.getSiteId();
    this.ROUTES[1].path = '/site/'+ this.siteId;
    this.Subscription = this.componentsService.getSiteNavigation(this.username, this.siteId)
    .pipe(
      map(map => {
        return {
          siteName: map.response.siteName,
          dashboard: map.response.dashboard,
          analytics: map.response.analytics,
          inverter: map.response.inverter,
          weatherStation: map.response.weatherStation,
          meter: map.response.meter,
          PV_DGSync: map.response.PV_DGSync,
          zeroExport: map.response.zeroExport,
          alarm: map.response.alarm,
          calendar: map.response.calendar,
          report: map.response.report,
          information: map.response.information
        };
      })
    )
    .subscribe(res => {
      this.ROUTES[1].title = res.siteName;
      this.ROUTES[1].children[0].flag = res.dashboard;
      this.ROUTES[1].children[1].flag = res.analytics;
      this.ROUTES[1].children[2].flag = res.inverter;
      this.ROUTES[1].children[3].flag = res.weatherStation;
      this.ROUTES[1].children[4].flag = res.meter;
      this.ROUTES[1].children[5].flag = res.PV_DGSync;
      this.ROUTES[1].children[6].flag = res.zeroExport;
      this.ROUTES[1].children[7].flag = res.alarm;
      this.ROUTES[1].children[8].flag = res.calendar;
      this.ROUTES[1].children[9].flag = res.report;
      this.ROUTES[1].children[10].flag = res.information;
    });

    this.menuItems = this.ROUTES.filter(menuItem => menuItem);
    this.router.events.subscribe(event => {
      this.isCollapsed = true;
    });
  }
  
  onMouseEnterSidenav() {
    if (!document.body.classList.contains("g-sidenav-pinned")) {
      document.body.classList.add("g-sidenav-show");
    }
  }
  onMouseLeaveSidenav() {
    if (!document.body.classList.contains("g-sidenav-pinned")) {
      document.body.classList.remove("g-sidenav-show");
    }
  }
  minimizeSidebar() {
    const sidenavToggler = document.getElementsByClassName(
      "sidenav-toggler"
    )[0];
    const body = document.getElementsByTagName("body")[0];
    if (body.classList.contains("g-sidenav-pinned")) {
      misc.sidebar_mini_active = true;
    } else {
      misc.sidebar_mini_active = false;
    }
    if (misc.sidebar_mini_active === true) {
      body.classList.remove("g-sidenav-pinned");
      body.classList.add("g-sidenav-hidden");
      sidenavToggler.classList.remove("active");
      misc.sidebar_mini_active = false;
    } else {
      body.classList.add("g-sidenav-pinned");
      body.classList.remove("g-sidenav-hidden");
      sidenavToggler.classList.add("active");
      misc.sidebar_mini_active = true;
    }
  }
}
