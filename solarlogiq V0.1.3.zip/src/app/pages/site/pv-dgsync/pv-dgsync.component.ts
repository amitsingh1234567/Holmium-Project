import { Component, OnInit, OnDestroy } from "@angular/core";
import { ActivatedRoute } from '@angular/router';

import { SiteService } from '../site.service';
import { takeUntil, map } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: "app-pv-dgsync",
  templateUrl: "pv-dgsync.component.html"
})
export class PV_DGSyncComponent implements OnInit, OnDestroy {

  private destroy = new Subject<void>();

  constructor( private route: ActivatedRoute, private siteService: SiteService) {}

  ngOnInit() {
    this.route.paramMap.pipe(
      map(ParamMap => ParamMap.get('id')),
      takeUntil(this.destroy)
    ).subscribe(siteId => this.siteService.updatePathParamState(siteId));
  }

  ngOnDestroy() {
    this.destroy.next();
    this.destroy.complete();
    this.siteService.updatePathParamState(null);
   }
}
