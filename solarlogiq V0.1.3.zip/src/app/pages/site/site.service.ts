import { Injectable } from "@angular/core";
import { HttpClient, HttpParams } from "@angular/common/http";
import { Subject, throwError, Observable, BehaviorSubject } from "rxjs";
import { Router, ActivatedRoute } from "@angular/router";

import { Response } from "./site.model";

@Injectable({ providedIn: "root" })
export class SiteService {
  
  private pathParamState = new Subject<string>();
  pathParam : Observable<string>;
  public siteId : string;

  constructor(private http: HttpClient, private router: Router, private route: ActivatedRoute) {
    this.pathParam = this.pathParamState.asObservable();
  }

  updatePathParamState(newPathParam:string){
   this.pathParamState.next(newPathParam);
  }
  
  async getSiteId () {
    await this.pathParam.subscribe( site => this.siteId=site );
    return this.siteId;
  }

  getSiteDevices(username: string, siteId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/site/devices?username="
    +username+"&siteid="+siteId)
  }

  getStringInverterCard(username: string, siteId: string, inverterId: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/inverter/stringInverterCard?username="
    +username+"&siteid="+siteId+"&inverterid="+inverterId)
  }

  getStringInverterCurve(username: string, siteId: string, inverterId: string, timestamp: string): Observable<Response> {
    return this.http.get<Response>("http://www.holmiumtechnologies.com/beta/rms/api/inverter/stringInverterCurve?username="
    +username+"&siteid="+siteId+"&inverterid="+inverterId+"&timestamp="+timestamp)
  }

}
