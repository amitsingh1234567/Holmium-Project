import { Component, OnInit,OnDestroy } from "@angular/core";
import { ActivatedRoute } from '@angular/router';

import { SiteService } from '../site.service';
import { takeUntil, map } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { FormControl, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material/core';

/** Error when invalid control is dirty, touched, or submitted. */
export class MyErrorStateMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted;
    return !!(control && control.invalid && (control.dirty || control.touched || isSubmitted));
  }
}

@Component({
  selector: "app-report",
  templateUrl: "report.component.html",
  styleUrls: ['./report.component.scss']
})
export class ReportComponent implements OnInit, OnDestroy {
  date = new FormControl(new Date());
  serializedDate = new FormControl((new Date()).toISOString());
  
  emailFormControl = new FormControl('', [
    Validators.required,
    Validators.email,
  ]);

  matcher = new MyErrorStateMatcher();
  
  private destroy = new Subject<void>();

  constructor( private route: ActivatedRoute, private siteService: SiteService) {}

  ngOnInit() {
    this.route.paramMap.pipe(
      map(ParamMap => ParamMap.get('id')),
      takeUntil(this.destroy)
    ).subscribe(siteId => this.siteService.updatePathParamState(siteId));
  }

  ngOnDestroy() {
    this.destroy.next();
    this.destroy.complete();
    this.siteService.updatePathParamState(null);
   }
}
