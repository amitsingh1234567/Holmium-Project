import { Component, OnInit, OnDestroy } from "@angular/core";
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

import { takeUntil, map, startWith, switchMap } from 'rxjs/operators';
import { Subject, Subscription, Observable, interval } from 'rxjs';

import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import * as _moment from 'moment';
import 'moment/locale/en-in';
import {default as _rollupMoment} from 'moment';

import * as Highcharts from 'highcharts';
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/export-data')(Highcharts);
const noData = require('highcharts/modules/no-data-to-display')
noData(Highcharts)

import { SiteService } from '../site.service';
import { AuthService } from '../../auth/auth.service';
import { StringInverterCard, StringInverterCurve } from '../site.model';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: "app-inverter",
  templateUrl: "inverter.component.html",
  styleUrls: ['./inverter.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
    {provide: MAT_DATE_LOCALE, useValue: 'en-IN'},
  ],
})
export class InverterComponent implements OnInit, OnDestroy {
  
  private destroy = new Subject<void>();
  private subscriptionDevices: Subscription;
  private subscriptionInverterCard: Subscription;
  private subscriptionInverterCurve: Subscription;
  timer$ : Observable<number> = interval(60000);
  
  public username: string;
  public siteId: string;
  public devices = [];
  public inverterCard : StringInverterCard ={
    timestamp: '--',
    status: '--',
    todayYield: '0 kWh',
    totalYield: '0 kWh',
    outputPower:'0 kW',
    inputPower: '0 kW',
    peakOutputPower: '0 kW',
    peakOutputPowerTimestamp: '--',
    specificYield: 0,
    specificPower: 0,
    temperature: '0 °C',
    efficiency: '0 %',
    capacity: '0 kW'
  }

  public selectedInverter : string;
  public selectedPerformanceOverview = '1';
  public selectedMPPTString= '1';
  public datePicker = new FormControl(moment());
  maxDate = moment();
  minDate = moment("01/01/2019", "MM-DD-YYYY");

  public stringInverterCurveData : StringInverterCurve ={
    time :[],
    dailyYield: [],
    totalYield :[],
    MPPT1:[],
    MPPT2:[]
  }

  highcharts = Highcharts;
  
  public performanceOverviewCurveOption : any = {   
      chart: {
         type: "spline",
         style: {
          fontFamily: "'Open Sans', sans-serif"
      }
      },
      credits: {
        enabled: false
      },
      tooltip :{
          shared: true,
          borderColor: '#2579A2'
      },
      title: {
         text: ""
      },
      xAxis:{
         categories:this.stringInverterCurveData.time
      },
      yAxis: [{ // Primary yAxis
        title: {
            text: 'Daily Yield (kWh)'
          },
        }, { // Secondary yAxis
        title: {
            text: 'Total Yield (kWh)',
        },
        opposite: true
      }],
      series: [{
        name: 'Daily Yield',
        data: this.stringInverterCurveData.dailyYield,
        color: '#4285F4',
        tooltip: {
        valueSuffix: ' kWh'
        } 
      },{
        name: 'Total Yield',
        yAxis:1,
        color: '#F4B400',
        data: this.stringInverterCurveData.totalYield,
        tooltip: {
        valueSuffix: ' kWh'
        }
      }],
      exporting: {
				buttons: {
					contextButton: {
            menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
             )
					}
				}
      },
      navigation: {
        buttonOptions: {
            verticalAlign: 'top',
            x: +5,
            y: -12
        }
      },
      plotOptions:{
        spline: {
          marker: {
              radius: 3,
              states: { hover: { radius: 6 } }
          },
        }
      },
  };

  public MPPTStringCurveOption : any = {   
    chart: {
       type: "spline",
       style: {
        fontFamily: "'Open Sans', sans-serif"
    }
    },
    // colors:["#7cb5ec", "#434348", "#90ed7d", "#f7a35c", "#8085e9", "#f15c80", "#e4d354", "#2b908f", "#f45b5b", "#91e8e1"],
    credits: {
      enabled: false
    },
    tooltip :{
        shared: true,
        borderColor: '#2579A2'
    },
    title: {
       text: ""
    },
    xAxis:{
       categories:this.stringInverterCurveData.time
    },
    yAxis: [{ // Primary yAxis
      title: {
          text: 'Current (A)'
        },
      }],
    series: [{
      name: 'MPPT1',
      data: this.stringInverterCurveData.MPPT1,
      tooltip: {
      valueSuffix: ' A'
      }
    },
    {
      name: 'MPPT2',
      data: this.stringInverterCurveData.MPPT2,
      tooltip: {
        valueSuffix: ' A'
        }
    }],
    exporting: {
      buttons: {
        contextButton: {
          menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
           )
        }
      }
    },
    navigation: {
      buttonOptions: {
          verticalAlign: 'top',
          x: +5,
          y: -12
      }
    },
    plotOptions:{
      spline: {
        marker: {
            radius: 3,
            states: { hover: { radius: 6 } }
        },
      }
    },
  };

  public updateFlag : boolean = false;
  public oneToOneFlag : boolean = true;

  constructor( private route: ActivatedRoute, private siteService: SiteService, private authService: AuthService) {
 
  }

  async ngOnInit() : Promise<void> {
   
    this.route.paramMap.pipe(
      map(ParamMap => ParamMap.get('id')),
      takeUntil(this.destroy)
    ).subscribe(siteId => this.siteService.updatePathParamState(siteId));
    this.username = this.authService.getUsername();
    this.siteId= await this.siteService.getSiteId();
    this.subscriptionDevices = this.siteService.getSiteDevices(this.username, this.siteId)
    .pipe(
      map(map => {
        return {
          devices:map.response.stringInverter
        };
      })
    )
    .subscribe(res => {
      res.devices.forEach(element => {
        this.devices.push({name:element.building+' '+element.name, id:element.id})
      });
      this.selectedInverter = this.devices[0].id.toString()
      this.inverterCards();
      this.inverterCurve();
   });
   
}

  inverterCards(){
    this.subscriptionInverterCard = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getStringInverterCard(this.username, this.siteId, this.selectedInverter)),
      map(map => {
        return {
          timestamp: map.response.timestamp,
          status: map.response.status,
          todayYield: map.response.todayYield,
          totalYield: map.response.totalYield,
          outputPower: map.response.outputPower,
          inputPower: map.response.inputPower,
          peakOutputPower: map.response.peakOutputPower,
          peakOutputPowerTimestamp: map.response.peakOutputPowerTimestamp,
          specificYield: map.response.specificYield,
          specificPower: map.response.specificPower,
          temperature: map.response.temperature,
          efficiency: map.response.efficiency,
          capacity: map.response.capacity
        };
      })
    )
    .subscribe(res => {
      this.inverterCard = res;
  });
  }

  inverterCurve(){
    this.subscriptionInverterCurve = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.siteService.getStringInverterCurve(this.username, this.siteId, this.selectedInverter,this.datePicker.value)),
      map(map => {
        return {
          time : map.response.time,
          dailyYield : map.response.dailyYield,
          totalYield : map.response.totalYield,
          outputCurrent : map.response.outputCurrent,
          inputCurrent : map.response.inputCurrent,
          outputPower : map.response.outputPower,
          inputPower : map.response.inputPower,
          temperature : map.response.temperature,
          efficiency : map.response.efficiency,
          MPPT1: map.response.currentMPPT1,
          MPPT2: map.response.currentMPPT2,
          MPPT3: map.response.currentMPPT3,
          MPPT4: map.response.currentMPPT4,
          MPPT5: map.response.currentMPPT5,
          MPPT6: map.response.currentMPPT6,
          MPPT7: map.response.currentMPPT7,
          MPPT8: map.response.currentMPPT8,
          MPPT9: map.response.currentMPPT9,
          MPPT10: map.response.currentMPPT10,
          MPPT11: map.response.currentMPPT11,
          MPPT12: map.response.currentMPPT12,
          MPPT13: map.response.currentMPPT13,
          MPPT14: map.response.currentMPPT14,
          MPPT15: map.response.currentMPPT15,
          String1: map.response.currentString1,
          String2: map.response.currentString2,
          String3: map.response.currentString3,
          String4: map.response.currentString4,
          String5: map.response.currentString5,
          String6: map.response.currentString6,
          String7: map.response.currentString7,
          String8: map.response.currentString8,
          String9: map.response.currentString9,
          String10: map.response.currentString10,
          String11: map.response.currentString11,
          String12: map.response.currentString12,
          String13: map.response.currentString13,
          String14: map.response.currentString14,
          String15: map.response.currentString15,
          String16: map.response.currentString16,
          String17: map.response.currentString17,
          String18: map.response.currentString18,
          String19: map.response.currentString19,
          String20: map.response.currentString20,
          String21: map.response.currentString21,
          String22: map.response.currentString22,
          String23: map.response.currentString23,
          String24: map.response.currentString24,
          String25: map.response.currentString25,
          String26: map.response.currentString26,
          String27: map.response.currentString27,
          String28: map.response.currentString28,
          String29: map.response.currentString29,
          String30: map.response.currentString30
        };
      })
    )
    .subscribe(res => {
      this.stringInverterCurveData = res;
    console.log( this.stringInverterCurveData)
      this.performanceOverviewCurveOption.xAxis={
        categories:this.stringInverterCurveData.time
      };

      this.performanceOverviewCurveOption.series=[];

      if(this.selectedPerformanceOverview == '1')
      {
        this.performanceOverviewCurveOption.yAxis=[{ 
          // Primary yAxis
          title: {
              text: 'Daily Yield (kWh)'
            },
          }, { // Secondary yAxis
          title: {
              text: 'Total Yield (kWh)',
          },
          opposite: true
        }];

        this.performanceOverviewCurveOption.series=[{
          name: 'Daily Yield',
          data: this.stringInverterCurveData.dailyYield,
          color: '#4285F4',
          tooltip: {
          valueSuffix: ' kWh'
          } 
        },{
          name: 'Total Yield',
          yAxis:1,
          data: this.stringInverterCurveData.totalYield,
          color: '#F4B400',
          tooltip: {
          valueSuffix: ' kWh'
          }
        }];
      }
      else if(this.selectedPerformanceOverview == '2')
      {
        this.performanceOverviewCurveOption.yAxis=[{ 
          // Primary yAxis
          title: {
              text: 'Output Power & Input Power (kW)'
            },
          }, { // Secondary yAxis
          title: {
              text: 'Output Current & Input Current (A)',
          },
          opposite: true
        }];
       
        this.performanceOverviewCurveOption.series=[{
          name: 'Output Power',
          data: this.stringInverterCurveData.outputPower,
          yAxis:0,
          color: '#EE2558',
          tooltip: {
          valueSuffix: ' kW',
          }
        }, {
          name: 'Input Power',
          data: this.stringInverterCurveData.inputPower,
          yAxis:0,
          color: '#1BB79A',
          tooltip: {
          valueSuffix: ' kW',
          }
        }, {
          name: 'Output Current',
          data: this.stringInverterCurveData.outputCurrent,
          yAxis:1,
          color: '#36A7E6',
          tooltip: {
          valueSuffix: ' A',
          }
        }, {
          name: 'Input Current',
          data: this.stringInverterCurveData.inputCurrent,
          yAxis:1,
          color: '#F4B400',
          tooltip: {
          valueSuffix: ' A',
          }
        }];
      }
      else if(this.selectedPerformanceOverview =='3')
      {
        this.performanceOverviewCurveOption.yAxis=[{ 
          // Primary yAxis
          title: {
              text: 'Efficiency (%)'
            },
          }, { // Secondary yAxis
          title: {
              text: 'Temperature (°C)',
          },
          opposite: true
        }];

        this.performanceOverviewCurveOption.series=[{
          name: 'Efficiency',
          data: this.stringInverterCurveData.efficiency,
          color: '#86C541',
          tooltip: {
          valueSuffix: ' %',
          }
        }, {
          name: 'Temperature',
          data: this.stringInverterCurveData.temperature,
          yAxis:1,
          color: '#F58731',
          tooltip: {
          valueSuffix: ' °C',
          }
        }];
      }

      this.MPPTStringCurveOption.xAxis={
        categories:this.stringInverterCurveData.time
      };
      
      this.MPPTStringCurveOption.series=[];

      if(this.selectedMPPTString == '1')
      {

        this.MPPTStringCurveOption.yAxis=[{ 
          title: {
              text: 'MPPT Current (A)'
            },
          }];

        this.MPPTStringCurveOption.series=[{
            name: 'MPPT 1',
            data: this.stringInverterCurveData.MPPT1,
            // color:'#dc4c8f',
            tooltip: {
            valueSuffix: ' A'
            }
          }, {
            name: 'MPPT 2',
            data: this.stringInverterCurveData.MPPT2,
            // color:'#47c3cd',
            tooltip: {
            valueSuffix: ' A'
            }
          }];

          if(this.stringInverterCurveData.MPPT3)
            this.MPPTStringCurveOption.series[2]={
              name: 'MPPT 3',
              data: this.stringInverterCurveData.MPPT3,
              // color:'#6F60B8',
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.stringInverterCurveData.MPPT4)
            this.MPPTStringCurveOption.series[3]={
              name: 'MPPT 4',
              data: this.stringInverterCurveData.MPPT4,
              //color:'#F27C47',
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.stringInverterCurveData.MPPT5)
            this.MPPTStringCurveOption.series[4]={
              name: 'MPPT 5',
              data: this.stringInverterCurveData.MPPT5,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.stringInverterCurveData.MPPT6)
            this.MPPTStringCurveOption.series[5]={
              name: 'MPPT 6',
              data: this.stringInverterCurveData.MPPT6,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.stringInverterCurveData.MPPT7)
            this.MPPTStringCurveOption.series[6]={
              name: 'MPPT 7',
              data: this.stringInverterCurveData.MPPT7,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.stringInverterCurveData.MPPT8)
            this.MPPTStringCurveOption.series[7]={
              name: 'MPPT 8',
              data: this.stringInverterCurveData.MPPT8,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.stringInverterCurveData.MPPT9)
            this.MPPTStringCurveOption.series[8]={
              name: 'MPPT 9',
              data: this.stringInverterCurveData.MPPT9,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.stringInverterCurveData.MPPT10)
            this.MPPTStringCurveOption.series[9]={
              name: 'MPPT 10',
              data: this.stringInverterCurveData.MPPT10,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.stringInverterCurveData.MPPT11)
            this.MPPTStringCurveOption.series[10]={
              name: 'MPPT 11',
              data: this.stringInverterCurveData.MPPT11,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.stringInverterCurveData.MPPT12)
            this.MPPTStringCurveOption.series[11]={
              name: 'MPPT 12',
              data: this.stringInverterCurveData.MPPT12,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.stringInverterCurveData.MPPT13)
            this.MPPTStringCurveOption.series[12]={
              name: 'MPPT 13',
              data: this.stringInverterCurveData.MPPT13,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.stringInverterCurveData.MPPT14)
            this.MPPTStringCurveOption.series[13]={
              name: 'MPPT 14',
              data: this.stringInverterCurveData.MPPT14,
              tooltip: {
              valueSuffix: ' A'
              }
            };

          if(this.stringInverterCurveData.MPPT15)
            this.MPPTStringCurveOption.series[14]={
              name: 'MPPT 15',
              data: this.stringInverterCurveData.MPPT15,
              tooltip: {
              valueSuffix: ' A'
              }
            };

      }
      else if(this.selectedMPPTString == '2')
      {
        this.MPPTStringCurveOption.yAxis=[{ 
          title: {
              text: 'String Current (A)'
            },
          }];

        if(this.stringInverterCurveData.String1)
          this.MPPTStringCurveOption.series[0]={
            name: 'String 1',
            data: this.stringInverterCurveData.String1,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.stringInverterCurveData.String2)
          this.MPPTStringCurveOption.series[1]={
            name: 'String 2',
            data: this.stringInverterCurveData.String2,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.stringInverterCurveData.String3)
          this.MPPTStringCurveOption.series[2]={
            name: 'String 3',
            data: this.stringInverterCurveData.String3,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.stringInverterCurveData.String4)
          this.MPPTStringCurveOption.series[3]={
            name: 'String 4',
            data: this.stringInverterCurveData.String4,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.stringInverterCurveData.String5)
          this.MPPTStringCurveOption.series[4]={
            name: 'String 5',
            data: this.stringInverterCurveData.String5,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.stringInverterCurveData.String6)
          this.MPPTStringCurveOption.series[5]={
            name: 'String 6',
            data: this.stringInverterCurveData.String6,
            tooltip: {
            valueSuffix: ' A'
            }
          };
          if(this.stringInverterCurveData.String7)
          this.MPPTStringCurveOption.series[6]={
            name: 'String 7',
            data: this.stringInverterCurveData.String7,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.stringInverterCurveData.String8)
          this.MPPTStringCurveOption.series[7]={
            name: 'String 8',
            data: this.stringInverterCurveData.String8,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.stringInverterCurveData.String9)
          this.MPPTStringCurveOption.series[8]={
            name: 'String 9',
            data: this.stringInverterCurveData.String9,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.stringInverterCurveData.String10)
          this.MPPTStringCurveOption.series[9]={
            name: 'String 10',
            data: this.stringInverterCurveData.String10,
            tooltip: {
            valueSuffix: ' A'
            }
          };
        if(this.stringInverterCurveData.String11)
          this.MPPTStringCurveOption.series[10]={
            name: 'String 11',
            data: this.stringInverterCurveData.String11,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String12)
          this.MPPTStringCurveOption.series[11]={
            name: 'String 12',
            data: this.stringInverterCurveData.String12,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String13)
          this.MPPTStringCurveOption.series[12]={
            name: 'String 13',
            data: this.stringInverterCurveData.String13,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String14)
          this.MPPTStringCurveOption.series[13]={
            name: 'String 14',
            data: this.stringInverterCurveData.String14,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String15)
          this.MPPTStringCurveOption.series[14]={
            name: 'String 15',
            data: this.stringInverterCurveData.String15,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String16)
          this.MPPTStringCurveOption.series[15]={
            name: 'String 16',
            data: this.stringInverterCurveData.String16,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String17)
          this.MPPTStringCurveOption.series[16]={
            name: 'String 17',
            data: this.stringInverterCurveData.String17,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String18)
          this.MPPTStringCurveOption.series[17]={
            name: 'String 18',
            data: this.stringInverterCurveData.String18,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String19)
          this.MPPTStringCurveOption.series[18]={
            name: 'String 19',
            data: this.stringInverterCurveData.String19,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String20)
          this.MPPTStringCurveOption.series[19]={
            name: 'String 20',
            data: this.stringInverterCurveData.String20,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String21)
          this.MPPTStringCurveOption.series[20]={
            name: 'String 21',
            data: this.stringInverterCurveData.String21,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String22)
          this.MPPTStringCurveOption.series[21]={
            name: 'String 22',
            data: this.stringInverterCurveData.String22,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String23)
          this.MPPTStringCurveOption.series[22]={
            name: 'String 23',
            data: this.stringInverterCurveData.String23,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String24)
          this.MPPTStringCurveOption.series[23]={
            name: 'String 24',
            data: this.stringInverterCurveData.String24,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String25)
          this.MPPTStringCurveOption.series[24]={
            name: 'String 25',
            data: this.stringInverterCurveData.String25,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String26)
          this.MPPTStringCurveOption.series[25]={
            name: 'String 26',
            data: this.stringInverterCurveData.String26,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String27)
          this.MPPTStringCurveOption.series[26]={
            name: 'String 27',
            data: this.stringInverterCurveData.String27,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String28)
          this.MPPTStringCurveOption.series[27]={
            name: 'String 28',
            data: this.stringInverterCurveData.String28,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String29)
          this.MPPTStringCurveOption.series[28]={
            name: 'String 29',
            data: this.stringInverterCurveData.String29,
            tooltip: {
            valueSuffix: ' A'
            }
          };

        if(this.stringInverterCurveData.String30)
          this.MPPTStringCurveOption.series[29]={
            name: 'String 30',
            data: this.stringInverterCurveData.String30,
            tooltip: {
            valueSuffix: ' A'
            }
          };
      }

      this.updateFlag=true;
      this.oneToOneFlag =true;
    });
  }
  
  changeInverter() {
    this.subscriptionInverterCard.unsubscribe();
    this.subscriptionInverterCurve.unsubscribe();
    this.inverterCards();
    this.inverterCurve();
  }

  changeDate(event: MatDatepickerInputEvent<Date>){
    this.datePicker.setValue(event.value)
    this.subscriptionInverterCurve.unsubscribe();
    this.inverterCurve();
  }

  changeSelection(){
    this.subscriptionInverterCurve.unsubscribe();
    this.inverterCurve();   
  }
  
  ngOnDestroy() {
    this.destroy.next();
    this.destroy.complete();
    this.siteService.updatePathParamState(null);
    this.subscriptionDevices.unsubscribe();
    this.subscriptionInverterCard.unsubscribe();
    this.subscriptionInverterCurve.unsubscribe();
   }
}
