import { Component, OnInit, OnDestroy, ViewChild } from "@angular/core";
import { ActivatedRoute } from '@angular/router';

import { SiteService } from '../site.service';
import { takeUntil, map } from 'rxjs/operators';
import { Subject } from 'rxjs';
// import { TabsetConfig } from 'ngx-bootstrap/tabs';

import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

export interface D_Log_Element {
  d_log_no: number;
  model_no: string;
  serial_no: string;
  block:string;
  device_connected: number;
}
export interface Inverter_Element {
  inverter_no: number;
  capacity: string;
  make: string;
  model_no:string;
  serial_no: string;
  block:string;
  strings:string;
}
export interface WeatherStation_Element {
  weatherstation_no: number;
  make: string;
  model_no:string;
  serial_no: string;
  block:string;
  sensors:string;
}
export interface Meter_Element {
  meter_no: number;
  make: string;
  model_no:string;
  serial_no: string;
  block:string;
}
export interface DieselGenerator_Element {
  dg_no: number;
  capacity: string;
  make: string;
  model_no:string;
  block:string;
}

const D_LOG_DATA: D_Log_Element[] = [
  {
    d_log_no: 1,
    model_no: 'D-LOG 201',
    serial_no: 'HO-K201001',
    block: 'Admin',
    device_connected:5
  },
  { 
    d_log_no: 11,
    model_no: 'D-LOG 101',
    serial_no: 'HO-K201001',
    block: 'Admin',
    device_connected:5
  }
];
const INVERTER_DATA: Inverter_Element[] = [
  {
    inverter_no: 1,
    capacity: '55kW',
    make: 'Delta',
    model_no: 'D-LOG 201',
    serial_no: 'HO-K201001',
    block: 'Admin',
    strings: '12'
  },
  { 
    inverter_no: 2,
    capacity: '55kW',
    make: 'Sungrow',
    model_no: 'D-LOG 201',
    serial_no: 'HO-K201001',
    block: 'Admin',
    strings: '12'
  }
];
const WEATHERSTATION_DATA: WeatherStation_Element[] = [
  {
    weatherstation_no: 1,
    make: 'Sivara',
    model_no: 'D-LOG 201',
    serial_no: 'HO-K201001',
    block: 'Admin',
    sensors: 'GTI, GHI, Module Temperature' 
  }
];
const METER_DATA: Meter_Element[] = [
  {
    meter_no: 1,
    make: 'Secure Meters limited',
    model_no: 'Premier-300',
    serial_no: 'HO-K201001',
    block: 'Admin'
  }
];
const DIESELGENERATOR_DATA: DieselGenerator_Element[] = [
  {
    dg_no: 1,
    capacity: '250kW',
    make: 'Greaves Power',
    model_no: 'Premier-300',
    block: 'Admin'
  }
];

@Component({
  selector: "app-information",
  templateUrl: "information.component.html",
  styleUrls: ['./information.component.scss']
  //providers: [{ provide: TabsetConfig, useFactory: getTabsetConfig }]
})

export class InformationComponent implements OnInit, OnDestroy {

  d_logColumns: string[] = ['d_log_no', 'model_no', 'serial_no', 'block', 'device_connected'];
  inverterColumns: string[] = ['inverter_no', 'capacity', 'make', 'model_no', 'serial_no', 'block', 'strings'];
  weatherStationColumns: string[] = ['weatherstation_no', 'make', 'model_no', 'serial_no', 'block', 'sensors'];
  meterColumns: string[] = ['meter_no', 'make', 'model_no', 'serial_no', 'block'];
  dieselGeneratorColumns: string[] = ['dg_no', 'capacity', 'make', 'model_no', 'block'];
  d_logSource = new MatTableDataSource<D_Log_Element>(D_LOG_DATA);
  inverterSource = new MatTableDataSource<Inverter_Element>(INVERTER_DATA);
  weatherStationSource = new MatTableDataSource<WeatherStation_Element>(WEATHERSTATION_DATA);
  meterSource = new MatTableDataSource<Meter_Element>(METER_DATA);
  dieselGeneratorSource = new MatTableDataSource<DieselGenerator_Element>(DIESELGENERATOR_DATA);

  applyFilterD_Log(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.d_logSource.filter = filterValue.trim().toLowerCase();
  }
  applyFilterInverter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.inverterSource.filter = filterValue.trim().toLowerCase();
  }
  applyFilterWeatherStation(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.weatherStationSource.filter = filterValue.trim().toLowerCase();
  }
  applyFilterMeter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.meterSource.filter = filterValue.trim().toLowerCase();
  }
  applyFilterDieselGenerator(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dieselGeneratorSource.filter = filterValue.trim().toLowerCase();
  }

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  
  private destroy = new Subject<void>();

  constructor( private route: ActivatedRoute, private siteService: SiteService) {}

  ngOnInit() {
    this.route.paramMap.pipe(
      map(ParamMap => ParamMap.get('id')),
      takeUntil(this.destroy)
    ).subscribe(siteId => this.siteService.updatePathParamState(siteId));
  }

  ngOnDestroy() {
    this.destroy.next();
    this.destroy.complete();
    this.siteService.updatePathParamState(null);
   }
}
