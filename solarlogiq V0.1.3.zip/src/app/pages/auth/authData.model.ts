export interface AuthData{
    username: string;
    password: string;
}