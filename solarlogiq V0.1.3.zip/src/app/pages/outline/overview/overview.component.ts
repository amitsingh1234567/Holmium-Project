import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Subscription, Observable } from 'rxjs';
import { interval } from "rxjs/internal/observable/interval";
import { startWith, switchMap, map } from "rxjs/operators";

import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';

import * as Highcharts from 'highcharts';
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/export-data')(Highcharts);

import { MapInfoWindow, MapMarker, GoogleMap } from '@angular/google-maps'

import { AuthService } from '../../auth/auth.service';
import { OutlineService } from '../outline.service'
import { UserLocation, OverviewCards, OverviewSiteLevel, OverviewSiteCurve } from '../outline.model';

@Component({
  selector: 'app-overview',
  templateUrl: './overview.component.html',
  styleUrls: ['./overview.component.scss']
})

export class OverviewComponent implements OnInit, OnDestroy{

  public username : string;
  private Subscription:Subscription;
  private SubscriptionSiteLevelAnalysis:Subscription;
  private SubscriptionMap:Subscription
  timer$ : Observable<number> = interval(30000);

  public overviewCards :  OverviewCards = {
    "totalCapacity": '0 kW',
    "netTodayEnergy": '0 kWh',
    "D_LOGStatus":'0 / 0 ',
    "inverterStatus": '0 / 0 ',
    "weatherStationStatus": '0 / 0 ',
    "meterStatus": '0 / 0 ',
    "powerControlStatus": '0 / 0 '
  }

  
  public displayedColumns: string[] = ['siteName', 'siteCapacity', 'status', 'dailyEnergy','outputPower','inputPower','pr', 'cuf'];
  public SiteLevelAnalysis: OverviewSiteLevel[] = [
    {
      siteName: "",
      siteCapacity: "",
      status: "",
      class:"",
      dailyEnergy: "",
      dailyEnergyCurve:0,
      specificEnergy:0,
      outputPower: "",
      inputPower: "",
      pr:"",
      cuf:""
    }
  ];
  public dataSource = new MatTableDataSource<OverviewSiteLevel>(this.SiteLevelAnalysis);

  public overviewSiteCurve : OverviewSiteCurve ={
    X1 :[this.SiteLevelAnalysis[0].siteName],
    Y1: [this.SiteLevelAnalysis[0].dailyEnergyCurve],
    Y2 :[this.SiteLevelAnalysis[0].specificEnergy]
  }

  highcharts = Highcharts;
  public chartOptions : any = {   
      chart: {
         type: "column",
         style: {
          fontFamily: "'Open Sans', sans-serif"
      }
      },
      credits: {
        enabled: false
      },
      tooltip :{
          shared: true,
          borderColor: '#2579A2'
      },
      title: {
         text: ""
      },
      xAxis:{
         categories:this.overviewSiteCurve.X1
      },
      yAxis: [{ // Primary yAxis
        title: {
            text: 'Yield (kWh)'
          },
        }, { // Secondary yAxis
        title: {
            text: 'Specific Yield',
        },
        opposite: true
      }],
      series: [{
        name: 'Yield',
        data: this.overviewSiteCurve.Y1,
        color: '#4285F4',
        tooltip: {
        valueSuffix: ' kWh'
        }
      },
      {
        name: 'Specific Yield',
        yAxis: 1,
        data: this.overviewSiteCurve.Y2,
        color: '#F4B400'
      }],
      exporting: {
				buttons: {
					contextButton: {
            menuItems: Highcharts.getOptions().exporting.buttons.contextButton.menuItems.filter(item => item !== 'separator'
             )
					}
				}
      },
      navigation: {
        buttonOptions: {
            verticalAlign: 'top',
            x: +5,
            y: -12
        }
      }
  };
  public updateFlag : boolean = false;

  public zoom = 5;
  public center: google.maps.LatLngLiteral;
  public options: google.maps.MapOptions = {
    zoomControl: true,
    scrollwheel: true,
    disableDoubleClickZoom: true,
    maxZoom: 15,
    minZoom: 2
  };
  public markers = [];
  public sites =[];
  public userLocation : UserLocation[] = [{
    siteName:'',
    location:'',
    coordinates:[]
  }];

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(GoogleMap, { static: false }) map: GoogleMap;
  @ViewChild(MapInfoWindow, { static: false }) info: MapInfoWindow

  constructor(public authService:AuthService, public outlineService: OutlineService){
      
  }
 
  ngOnInit() {

    this.username = this.authService.getUsername();
    this.SubscriptionMap = this.outlineService.getUserProfile(this.username)
    .pipe(
      map(map => {
        return {
          res:map.response.plants,
        };
      })
    )
    .subscribe(res => {
      this.sites = res['res'];
      this.sites.forEach(element => {
        this.markers.push({
          position: {
            lat: +element.coordinates[0],
            lng: +element.coordinates[1]
          },
          label: {
            color: "#2579A2",
            text: " "
          },
          title: element.plantName+', '+ element.location,
          options: {
            animation: google.maps.Animation.DROP
          }
        });
        this.center={
          lat: +element.coordinates[0],
          lng: +element.coordinates[1]
        };
      });
    });
    
    this.Subscription = this.timer$.pipe(
        startWith(0),
        switchMap(() => this.outlineService.getOverviewCards(this.username)),
        map(map => {
          return {
            "totalCapacity": map.response.totalCapacity,
            "netTodayEnergy": map.response.todayEnergy,
            "D_LOGStatus": map.response.D_LOGStatus,
            "inverterStatus": map.response.inverterStatus,
            "weatherStationStatus": map.response.weatherStationStatus,
            "meterStatus": map.response.meterStatus,
            "powerControlStatus": map.response.powerControlStatus
          };
        })
      )
      .subscribe(res => {
        this.overviewCards = res;
    });

    this.SubscriptionSiteLevelAnalysis = this.timer$.pipe(
      startWith(0),
      switchMap(() => this.outlineService.getOverviewSiteLevel(this.username)),
      map(map => {
        return {
          "res": map.response,
        };
      })
    )
    .subscribe(res => {
      this.SiteLevelAnalysis = res['res'];
      this.overviewSiteCurve.X1=[];
      this.overviewSiteCurve.Y1=[];
      this.overviewSiteCurve.Y2=[];
      this.SiteLevelAnalysis.forEach(element => {
        this.overviewSiteCurve.X1.push(element.siteName);
        this.overviewSiteCurve.Y1.push(+element.dailyEnergyCurve);
        this.overviewSiteCurve.Y2.push(+element.specificEnergy)
      });
      this.chartOptions.xAxis={
        categories:this.overviewSiteCurve.X1
      };
      this.chartOptions.series= [{
          data: this.overviewSiteCurve.Y1
        },{
          data: this.overviewSiteCurve.Y2
        }];
    
      this.updateFlag = true;
      this.dataSource = new MatTableDataSource<OverviewSiteLevel>(this.SiteLevelAnalysis);
    });
    this.dataSource.paginator = this.paginator;
   }
  
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  ngOnDestroy(){
    this.Subscription.unsubscribe();
    this.SubscriptionSiteLevelAnalysis.unsubscribe();
    this.SubscriptionMap.unsubscribe();
   }

}