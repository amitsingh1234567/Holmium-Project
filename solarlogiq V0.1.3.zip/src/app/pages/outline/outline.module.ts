import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
//import { FormsModule } from "@angular/forms";

import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatInputModule } from '@angular/material/input';

import { BsDropdownModule } from "ngx-bootstrap";
import { CarouselModule } from 'ngx-bootstrap/carousel';
// import { ProgressbarModule } from "ngx-bootstrap/progressbar";
// import { TooltipModule } from "ngx-bootstrap/tooltip";

import { HighchartsChartModule } from 'highcharts-angular';
import { GoogleMapsModule } from '@angular/google-maps';

import { OverviewComponent } from "./overview/overview.component";
import { ProfileComponent } from "./profile/profile.component";

import { RouterModule } from "@angular/router";
import { OutlineRoutes } from "./outline.routing";


// import { AuthGuard } from '../../auth-strategy/auth.guard';

@NgModule({
  declarations: [ OverviewComponent, ProfileComponent ],
  imports: [
    CommonModule,
    RouterModule.forChild(OutlineRoutes),
    BsDropdownModule,
    CarouselModule.forRoot(),
    MatTableModule,
    MatPaginatorModule,
    MatInputModule ,
    HighchartsChartModule,
    GoogleMapsModule
  ],
  exports: [ OverviewComponent, ProfileComponent ],
  providers: [  ],
})
export class OutlineModule { }
