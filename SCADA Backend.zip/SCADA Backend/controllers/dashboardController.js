const url = require('url');
const dashboardService=require('../services/dashboardService');

exports.dashboardCardController = (req,res,next)=>{
    dashboardService.dashboardCardService(req.query.username,req.query.siteid)
    .then((response)=>{
        if(!response.status){
            throw new Error(response.message); 
        }     
        res.status(200).json({
            message: true,
            response: response.response
        })
    })
    .catch((err)=>{
        console.log(err);
        res.status(401).json({
            status: false,
            message: err.message
        });
    });
}

exports.dashboardSiteLevelStatusController = (req,res,next)=>{
    dashboardService.dashboardSiteLevelStatusService(req.query.username,req.query.siteid)
    .then((response)=>{
        if(!response.status){
            throw new Error(response.message); 
        }     
        res.status(200).json({
            message: true,
            response: response.response
        })
    })
    .catch((err)=>{
        console.log(err);
        res.status(401).json({
            status: false,
            message: err.message
        });
    });
}

exports.dashboardCurveController = (req,res,next)=>{
    dashboardService.dashboardCurveService(req.query.username,req.query.siteid)
    .then((response)=>{
        if(!response.status){
            throw new Error(response.message); 
        }     
        res.status(200).json({
            message: true,
            response: response.response
        })
    })
    .catch((err)=>{
        console.log(err);
        res.status(401).json({
            status: false,
            message: err.message
        });
    });
}